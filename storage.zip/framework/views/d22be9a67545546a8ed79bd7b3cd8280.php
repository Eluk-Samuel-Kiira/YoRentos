<div>
    <section class="find_section ">
        <div class="container">
            <form action="">
                <div class="container-header">
                    <h2 class="rental_heading">
                        <?php echo e(__('Let\'s Search Your Dream Rental Now!')); ?>

                    </h2>
                </div>
                <div class="form-row">
                    <!-- countries -->
                    <div class="col-md-2">
                        <select class="form-control" wire:model.lazy="selectedCountry">
                            <option value="">Select Country</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->country); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                    <!-- Districts -->
                    <div class="col-md-2">
                        <select class="form-control" wire:model.lazy="selectedDistrict">
                            <option value="">Select District</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($district->id); ?>"><?php echo e($district->district); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                    <!-- counties/Constituency -->
                    <div class="col-md-2">
                        <select class="form-control" wire:model.lazy="selectedCounty">
                            <option value="">Select County/Constituency</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $counties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $county): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($county->id); ?>"><?php echo e($county->county); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                    <!-- sub-counties/Divisons -->
                    <div class="col-md-2">
                        <select class="form-control" wire:model.lazy="selectedSubcounty">
                            <option value="">Select Sub-County/Division</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $subcounties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcounty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($subcounty->id); ?>"><?php echo e($subcounty->subcounty); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                    <!-- parishes/wards -->
                    <div class="col-md-2">
                        <select class="form-control" wire:model.lazy="selectedParish">
                            <option value="">Select Parish/Ward</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $parishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($parish->id); ?>"><?php echo e($parish->parish); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                    <!-- villages -->
                    <div class="col-md-2">
                        <select class="form-control" wire:model.lazy="selectedVillage">
                            <option value="">Select Village/Cell</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $villages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $village): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($village->id); ?>"><?php echo e($village->village); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                    <!-- Rental types -->
                    <div class="col-md-2">
                        <select class="form-control" wire:model.lazy="selectedRental">
                            <option value="">Select Rental</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $rentals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($rental->id); ?>"><?php echo e($rental->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                </div>
            </form>
        </div>
    </section>
    <section class="sale_section">
        <div class="container-header">
            <h2 class="rental_heading">
                <!--[if BLOCK]><![endif]--><?php if($selected_rental): ?>
                    <?php echo e($selected_rental->name); ?>

                <?php else: ?>
                    <?php echo e(('No Rental Type Selected')); ?>

                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </h2>
        </div>
        <div class="container-fluid">
            <div class="sale_container">
                <!--[if BLOCK]><![endif]--><?php if($selected_rental && $select_estates): ?>
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $select_estates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="box">
                            <div class="img-box">
                                <div class="carousel">
                                    <!--[if BLOCK]><![endif]--><?php if($estate->images): ?>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = explode(',', $estate->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="slide">
                                                <img src="<?php echo e(asset('storage/estate_images/' . $estate->landlord_id . '/' . $imageName)); ?>" alt="" >
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                                    <?php else: ?>
                                        <div><img src="<?php echo e(asset('frontend/images/s-2.jpg')); ?>" alt=""></div>
                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                            <div class="detail-box">
                                <h6>
                                    <a href="<?php echo e(route('unit.detail', $estate)); ?>"><?php echo e($estate->estate); ?> </a>                           
                                    <span class="btn btn-small" style="background-color: yellow; color: &#9654;">
                                    <?php
                                        $minPrice = $estate->unitEstate->min('price');
                                        $maxPrice = $estate->unitEstate->max('price');
                                    ?>
                                    <!--[if BLOCK]><![endif]--><?php if($minPrice !== null && $maxPrice !== null): ?>
                                        <?php echo e($minPrice); ?> - <?php echo e($maxPrice); ?>

                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                    </span>
                                </h6>
                                <p>
                                    <span class="btn btn-small">
                                        <?php
                                            $availableUnits = $estate->unitEstate->where('status', 0)->count();
                                            $allUnits = $estate->unitEstate->count();
                                        ?>
                                            <?php echo e(__('Units Available: ')); ?>

                                        <!--[if BLOCK]><![endif]--><?php if($availableUnits !== 0): ?> 
                                            <?php echo e($availableUnits); ?>/<?php echo e($allUnits); ?>

                                        <?php else: ?>
                                            <?php echo e(__('NONE')); ?>

                                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                    </span>
                                    <span class="btn btn-primary btn-small" style="display: inline-block; white-space: nowrap;">
                                        <img src="<?php echo e(asset('frontend/images/location.png')); ?>" width="10px" style="display: inline-block; vertical-align: middle; margin-right: 5px;" alt="">
                                        <span style="display: inline-block; vertical-align: middle;">
                                            <?php echo e($estate->villageEstate->village); ?>

                                        </span>
                                    </span>
                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                <?php else: ?>
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </section>
</div>
<?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/livewire/search-component.blade.php ENDPATH**/ ?>