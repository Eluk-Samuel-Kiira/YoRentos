<script>
    function toggleUnits(estateUid) {
        const element = document.getElementById(`unit_${estateUid}`);
        if (element) {
            element.classList.toggle('hidden');
        }
    }
</script>

<div class="w-full md:w-1/3 bg-gray-200 rounded-lg p-2 hidden" id="unit_<?php echo e($estate->uid); ?>">
    <div class="w-full max-w-sm mx-auto">
        <?php if(session('estate_id') == $estate->id): ?>
            <form method="POST" action="https://checkout.flutterwave.com/v3/hosted/pay" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="tx_ref" value="<?php echo e(session('txn_ref')); ?>" required/>
                <input type="hidden" name="public_key" value="FLWPUBK-1c35c3c26e1701045fe66ad993f291a5-X" />
                <input type="hidden" name="amount" value="<?php echo e(session('amount')); ?>" />
                <input type="hidden" name="currency" value="UGX" />
                <input type="hidden" name="type" value="mobile_money_uganda" />
                <input type="hidden" name="meta[token]" value="54" />
                <input type="hidden" name="customer[name]" value="<?php echo e(auth()->user()->name); ?>" />
                <input type="hidden" name="customer[email]" value="<?php echo e(auth()->user()->email); ?>" />
                <input type="hidden" name="customer[phone_number]" value="<?php echo e(auth()->user()->phone_number); ?>" />
                <input type="hidden" name="redirect_url" value="https://yorentos.stardena.com/estate" />
                <input type="text" name="amount" value="<?php echo e(session('amount')); ?>" style="border: none" disabled/>
                <!-- <input type="text" name="amount" value="<?php echo e($estate->id); ?>" style="border: none" disabled/> -->
                <div class="flex items-center justify-between">
                    <button type="submit" class="bg-blue-500 text-white px-3 py-1 rounded-sm text-sm hover:bg-blue-600 motion-reduce:transform-none">
                        CheckOut
                    </button>
                </div>
            </form>
        <?php else: ?>
            <form method="POST" action="<?php echo e(route('payment.units')); ?>" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="landlord_id" name="landlord_id" value="<?php echo e($estate->landlord_id); ?>" required>
                <input type="hidden" id="estate_uid" name="estate_uid" value="<?php echo e($estate->uid); ?>" required>
                <input type="hidden" id="estate_id" name="estate_id" value="<?php echo e($estate->id); ?>" required>
                <div class="mt-4">
                    <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label','data' => ['for' => 'unit-pay','value' => ''.e(__('Select Monthly Unit Packages')).'','class' => 'block text-gray-700 text-sm font-bold mb-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'unit-pay','value' => ''.e(__('Select Monthly Unit Packages')).'','class' => 'block text-gray-700 text-sm font-bold mb-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                    <!-- <div>
                        <input type="checkbox" id="unit-mgt" name="unit_pay[]" value="500" class="mr-2" required>
                        <label for="units" class="rounded">Manage Units at 500/unit</label>
                    </div> -->
                    <div>
                        <input type="checkbox" id="unit-mgt" name="unit_pay[]" value="1500" class="mr-2">
                        <label for="units" class="rounded">Timely Notifications at 1500/unit</label>
                    </div>
                </div>
                <div class="flex items-center justify-between">
                    <button type="submit" class="bg-blue-500 text-white px-3 py-1 rounded-sm text-sm hover:bg-blue-600 motion-reduce:transform-none">
                        Process Payments
                    </button>
                </div>
            </form>
        <?php endif; ?>
        <?php if(request()->query('status') == 'successful'): ?>
            <div class="flex justify-center px-3 py-2 border-l-4 border-indigo-400 text-base font-medium text-indigo-700 bg-indigo-50 focus:outline-none focus:text-indigo-800 focus:bg-indigo-100 focus:border-indigo-700">
                <?php echo e(__('Your Payment is succeessful')); ?>

            </div>
        <?php elseif(request()->query('status') == 'cancelled'): ?>
            <!-- this is just a security measure for typos -->
            <?php
                $cancelled_txn = \App\Models\Unitpay::where('txn_ref', request()->query('tx_ref'))->first();
                if ($cancelled_txn) {
                    $cancelled_txn->delete();
                }
            ?>
            <div class="flex justify-center px-3 py-2 border-l-4 border-indigo-400 text-base font-medium text-indigo-700 bg-indigo-50 focus:outline-none focus:text-indigo-800 focus:bg-indigo-100 focus:border-indigo-700">
                <?php echo e(__('Your Transaction Has Failed or been Cancelled')); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var status = "<?php echo e(request()->query('status')); ?>"; // Get the status
        var txRef = "<?php echo e(request()->query('tx_ref')); ?>";
        var user_id = "<?php echo e(auth()->user()->id); ?>";
        var landlord = "<?php echo e($estate->landlord_id); ?>";
        if ( landlord == user_id) {
            if (status === 'successful' && txRef) {
                $.ajaxSetup({
                    headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                // Send an AJAX request to delete the image
                $.ajax({
                    url: '<?php echo e(route('pay.unit-status')); ?>', 
                    method: 'POST',
                    data: { txRef: txRef,
                    },
                    success: function(response) {
                        console.log(response);
                    },
                    error: function(xhr, status, error) {
                        // Handle error
                        console.error(error);
                    }
                }); 
            } else {
                // console.log('Transaction Failed');
            }
        }
    });

</script>
<?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/estates/pay-unit.blade.php ENDPATH**/ ?>