<script>
    function toggleAdvert(estateUid) {
        const element = document.getElementById(`advertise_${estateUid}`);
        if (element) {
            element.classList.toggle('hidden');
        }
    }
</script>

<div class="w-full md:w-1/3 bg-gray-200 rounded-lg p-2 hidden" id="advertise_<?php echo e($estate->uid); ?>">
    <div class="w-full max-w-sm mx-auto">
        <?php if(session('estate_id') == $estate->id): ?>
            <form method="POST" action="https://checkout.flutterwave.com/v3/hosted/pay" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="tx_ref" value="<?php echo e(session('txn_ref')); ?>" required/>
                <input type="hidden" name="public_key" value="FLWPUBK-1c35c3c26e1701045fe66ad993f291a5-X" />
                <input type="hidden" name="amount" value="<?php echo e(session('amount')); ?>" />
                <input type="hidden" name="currency" value="UGX" />
                <input type="hidden" name="type" value="mobile_money_uganda" />
                <input type="hidden" name="meta[token]" value="54" />
                <input type="hidden" name="customer[name]" value="<?php echo e(auth()->user()->name); ?>" />
                <input type="hidden" name="customer[email]" value="<?php echo e(auth()->user()->email); ?>" />
                <input type="hidden" name="customer[phone_number]" value="<?php echo e(auth()->user()->phone_number); ?>" />
                <input type="hidden" name="redirect_url" value="https://yorentos.stardena.com/estate" />
                <input type="text" name="amount" value="<?php echo e(session('amount')); ?>" style="border: none" disabled/>
                <!-- <input type="text" name="amount" value="<?php echo e($estate->id); ?>" style="border: none" disabled/> -->
                <div class="flex items-center justify-between">
                    <button type="submit" class="bg-blue-500 text-white px-3 py-1 rounded-sm text-sm hover:bg-blue-600 motion-reduce:transform-none">
                        CheckOut
                    </button>
                </div>
            </form>
        <?php else: ?>
            <form method="POST" action="<?php echo e(route('payment.advert')); ?>" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="landlord_id" name="landlord_id" value="<?php echo e($estate->landlord_id); ?>" required>
                <input type="hidden" id="estate_uid" name="estate_uid" value="<?php echo e($estate->uid); ?>" required>
                <input type="hidden" id="estate_id" name="estate_id" value="<?php echo e($estate->id); ?>" required>
                <div class="mb-4">
                    <label for="amount" class="block text-gray-700 text-sm font-bold mb-2">Select Package</label>
                    <select id="amount" class="w-full font-medium py-2 rounded text-gray-700" name="amount" required>
                        <option class="block mt-1 w-full" value=""></option>
                        <option class="block mt-1 w-full" value="10000">Ugx: 10000 Only In Your District</option>
                        <option class="block mt-1 w-full" value="30000">Ugx: 30000 Entire Country</option>
                    </select>      
                </div>
                <div class="flex items-center justify-between">
                    <button type="submit" class="bg-blue-500 text-white px-3 py-1 rounded-sm text-sm hover:bg-blue-600 motion-reduce:transform-none">
                        Save Details
                    </button>
                </div>
            </form>
        <?php endif; ?>
        <?php if(request()->query('status')== 'successful'): ?>
            <div class="flex justify-center px-3 py-2 border-l-4 border-indigo-400 text-base font-medium text-indigo-700 bg-indigo-50 focus:outline-none focus:text-indigo-800 focus:bg-indigo-100 focus:border-indigo-700">
                <?php echo e(__('Your Payment is succeessful')); ?>

            </div>
        <?php elseif(request()->query('status')== 'cancelled'): ?>
            <!-- this is just a security measure for typos -->
            <?php
                $cancelled_txn = \App\Models\Unitpay::where('txn_ref', request()->query('tx_ref'))->first();
                if ($cancelled_txn) {
                    $cancelled_txn->delete();
                }
            ?>
            <div class="flex justify-center px-3 py-2 border-l-4 border-indigo-400 text-base font-medium text-indigo-700 bg-indigo-50 focus:outline-none focus:text-indigo-800 focus:bg-indigo-100 focus:border-indigo-700">
                <?php echo e(__('Your Transaction Has Failed or been Cancelled')); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        var status = "<?php echo e(request()->query('status')); ?>"; // Get the status
        var txRef = "<?php echo e(request()->query('tx_ref')); ?>";
        var user_id = "<?php echo e(auth()->user()->id); ?>";
        var landlord = "<?php echo e($estate->landlord_id); ?>";
        if ( landlord == user_id) {
            if (status === 'successful' && txRef) {
                $.ajaxSetup({
                    headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                // Send an AJAX request to delete the image
                $.ajax({
                    url: '<?php echo e(route('pay.status')); ?>', 
                    method: 'POST',
                    data: { txRef: txRef,
                    },
                    success: function(response) {
                        console.log(response);
                    },
                    error: function(xhr, status, error) {
                        // Handle error
                        console.error(error);
                    }
                }); 
            } else {
                // console.log('Transaction Failed');
            }
        }
    });

</script>
<?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/estates/advertise-estate.blade.php ENDPATH**/ ?>