<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<title>Dashboard | YoRentos</title>
<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <h4>  
        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => ['class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>  
        <?php if(session('error')): ?>
            <span class="bg-red-500 text-white rounded">
                <?php echo e(session('error')); ?>

            </span>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <span class="bg-green-500 text-white rounded">
                <?php echo e(session('success')); ?>

            </span>
        <?php endif; ?>
    </h4>
                    
    <!-- find section -->
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('search-component', []);

$__html = app('livewire')->mount($__name, $__params, 'ZWZ33zU', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    <!-- end find section -->

    <!-- newly sponsored houses section -->
    <section class="sale_section layout_padding">
        <div class="container-fluid">
            <div class="container-header">
                <h2 class="rental_heading">
                    <?php echo e(__('Top Quality Houses Available In The Country')); ?>

                </h2>
            </div>
            <div class="sale_container">
                <?php 
                    $imageCount = 0;
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $newly_estates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="box">
                        <div class="img-box">
                            <div class="carousel">
                                <?php if($estate->images): ?>
                                    <?php $__currentLoopData = explode(',', $estate->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="slide">
                                            <img src="<?php echo e(asset('storage/estate_images/' . $estate->landlord_id . '/' . $imageName)); ?>" alt="" >
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div><img src="<?php echo e(asset('frontend/images/s-2.jpg')); ?>" alt=""></div>
                                <?php endif; ?>
                            </div>
                            <button class="prev" onclick="prevSlide(<?php echo e($imageCount); ?>)"><span class="arrow">&#9664;</span> </button>
                            <button class="next" onclick="nextSlide(<?php echo e($imageCount); ?>)"> <span class="arrow">&#9654;</span></button>
                            <?php $imageCount++ ?>
                        </div>
                        <div class="detail-box">
                            <h6>
                                <a href="<?php echo e(route('unit.detail', $estate)); ?>"><?php echo e($estate->estate); ?> </a>                           
                                <span class="btn btn-small">
                                <?php
                                    $minPrice = $estate->unitEstate->min('price');
                                    $maxPrice = $estate->unitEstate->max('price');
                                ?>
                                <?php if($minPrice !== null && $maxPrice !== null): ?>
                                    <?php echo e($minPrice); ?> - <?php echo e($maxPrice); ?>

                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                                </span>
                            </h6>
                            <p>
                                <span class="btn btn-small">
                                    <?php
                                        $availableUnits = $estate->unitEstate->where('status', 0)->count();
                                        $allUnits = $estate->unitEstate->count();
                                    ?>
                                        <?php echo e(__('Units Available: ')); ?>

                                    <?php if($availableUnits !== 0): ?> 
                                        <?php echo e($availableUnits); ?>/<?php echo e($allUnits); ?>

                                    <?php else: ?>
                                        <?php echo e(__('NONE')); ?>

                                    <?php endif; ?>
                                </span>
                                <span class="btn btn-small">
                                    <img src="<?php echo e(asset('frontend/images/location.png')); ?>" width="10px" style="display: inline-block; vertical-align: middle; margin-right: 5px;" alt="">
                                    <?php echo e($estate->villageEstate->village); ?>

                                </span>
                                <span class="btn btn-small">
                                    <?php echo e($estate->unit_no); ?><?php echo e(__(' Reviews')); ?>

                                </span>
                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>
                        <?php echo e(__('There are no Sponsored Estates')); ?>

                    </p>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- end newly sponsored houses section -->

    <!-- within area -->
    <div class="slider-container">
        <div class="container-header">
            <h2 class="rental_heading">
                <?php echo e(__('Most Search Rentals In Your Location')); ?>

            </h2>
        </div>
        <div class="slider scroll-container">
            <?php $__empty_1 = true; $__currentLoopData = $estates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="slided">
                    <?php
                        $firstImage = 0;
                    ?>
                    <?php if($estate->images): ?>
                        <?php $__currentLoopData = explode(',', $estate->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="slide">
                                <img src="<?php echo e(asset('storage/estate_images/' . $estate->landlord_id . '/' . $imageName)); ?>" alt="">
                            </div>
                            <?php
                                $firstImage++;
                                if ($firstImage >= 1) {
                                    break; // Stops the loop 
                                }
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div><img src="<?php echo e(asset('frontend/images/s-2.jpg')); ?>" alt=""></div>
                    <?php endif; ?>
                    <div class="detail-box">
                        <h6>
                            <a href="<?php echo e(route('unit.detail', $estate)); ?>"><?php echo e($estate->estate); ?> </a>     
                        </h6>
                    </div>
                    <span class="btn btn-primary btn-small" style="display: inline-block; white-space: nowrap;">
                        <span style="display: inline-block; vertical-align: middle;">
                            <?php echo e($estate->villageEstate->village); ?>

                        </span>
                    </span>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="detail-box">
                    <h6>
                        <?php echo e(__('No Estates Available')); ?>

                    </h6>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <!-- within area -->
    
    <!--  sponsored houses section -->
    <section class="sale_section layout_padding">
        <div class="container-fluid">
            <div class="container-header">
                <h2 class="rental_heading">
                    <?php echo e(__('Other Quality Houses')); ?>

                </h2>
            </div>
            <div class="sale_container">
                <?php $__empty_1 = true; $__currentLoopData = $early_estates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="box">
                        <div class="img-box">
                            <div class="carousel">
                                <?php if($estate->images): ?>
                                    <?php $__currentLoopData = explode(',', $estate->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="slide">
                                            <img src="<?php echo e(asset('storage/estate_images/' . $estate->landlord_id . '/' . $imageName)); ?>" alt="" >
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div><img src="<?php echo e(asset('frontend/images/s-2.jpg')); ?>" alt=""></div>
                                <?php endif; ?>
                            </div>
                            <button class="prev" onclick="prevSlide(<?php echo e($imageCount); ?>)"><span class="arrow">&#9664;</span> </button>
                            <button class="next" onclick="nextSlide(<?php echo e($imageCount); ?>)"> <span class="arrow">&#9654;</span></button>
                            <?php $imageCount++ ?>
                        </div>
                        <div class="detail-box">
                            <h6>
                                <a href="<?php echo e(route('unit.detail', $estate)); ?>"><?php echo e($estate->estate); ?> </a>                           
                                <span class="btn btn-small">
                                <?php
                                    $minPrice = $estate->unitEstate->min('price');
                                    $maxPrice = $estate->unitEstate->max('price');
                                ?>
                                <?php if($minPrice !== null && $maxPrice !== null): ?>
                                    <?php echo e($minPrice); ?> - <?php echo e($maxPrice); ?>

                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                                </span>
                            </h6>
                            <p>
                                <span class="btn btn-small">
                                    <?php
                                        $availableUnits = $estate->unitEstate->where('status', 0)->count();
                                        $allUnits = $estate->unitEstate->count();
                                    ?>
                                        <?php echo e(__('Units Available: ')); ?>

                                    <?php if($availableUnits !== 0): ?> 
                                        <?php echo e($availableUnits); ?>/<?php echo e($allUnits); ?>

                                    <?php else: ?>
                                        <?php echo e(__('NONE')); ?>

                                    <?php endif; ?>
                                </span>
                                <span class="btn btn-small">
                                    <img src="<?php echo e(asset('frontend/images/location.png')); ?>" width="10px" style="display: inline-block; vertical-align: middle; margin-right: 5px;" alt="">
                                    <?php echo e($estate->villageEstate->village); ?>

                                </span>
                                <span class="btn btn-small">
                                    <?php echo e($estate->unit_no); ?><?php echo e(__(' Reviews')); ?>

                                </span>
                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>
                        <?php echo e(__('There are no Sponsored Estates')); ?>

                    </p>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- end  sponsored houses section -->

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.user_location', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    let slideIndex = 0;
    const slides = document.querySelectorAll('.slided');

    function moveSlide(n) {
    slideIndex += n;
    if (slideIndex < 0) {
        slideIndex = slides.length - 1;
    } else if (slideIndex >= slides.length) {
        slideIndex = 0;
    }
    updateSliderPosition();
    }

    function updateSliderPosition() {
    const slideWidth = slides[0].offsetWidth;
    const offset = -slideIndex * slideWidth;
    document.querySelector('.slider').style.transform = `translateX(${offset}px)`;
    }

    // Update slider position initially
    updateSliderPosition();
</script><?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/tenant/dashboard.blade.php ENDPATH**/ ?>