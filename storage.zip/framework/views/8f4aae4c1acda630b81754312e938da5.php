<?php echo $__env->make('dashboard.tenant-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.not-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Income')); ?> 
        </h2>
        <h4>  
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => ['class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>  
            <?php if(session('error')): ?>
                <span class="bg-red-500 text-white rounded">
                    <?php echo e(session('error')); ?>

                </span>
            <?php endif; ?>
            <?php if(session('success')): ?>
                <span class="bg-green-500 text-white rounded">
                    <?php echo e(session('success')); ?>

                </span>
            <?php endif; ?>
        </h4>
        <h6>
            <div id="error-container"></div>
        </h6>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="max-w-7xl mx-auto p-6">
                    <!-- advert table -->
                    <div class="table-responsive" style="overflow-x: auto;">
                        <div class="container mx-auto mt-8">
                        <input type="text" class="rounded text-gray-500" id="advertSearch" placeholder="Search Adverts">
                            <button onclick="hideTable()" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                                &times;Hide
                            </button>
                            <button class="bg-green-500 text-white font-bold py-2 px-4 rounded">
                                Total Amount: <?php echo e($total_estate); ?>

                            </button>
                            <table class="min-w-full border border-blue-500 text-gray-500" id="advertTable">
                                <thead>
                                    <tr>
                                        <th class="py-2 px-4 border border-blue-500">ID</th>
                                        <th class="py-2 px-4 border border-blue-500">Estate Name</th>
                                        <th class="py-2 px-4 border border-blue-500">Landlord</th>
                                        <th class="py-2 px-4 border border-blue-500">Amount</th>
                                        <th class="py-2 px-4 border border-blue-500">Transaction Id</th>
                                        <th class="py-2 px-4 border border-blue-500">Start Date</th>
                                        <th class="py-2 px-4 border border-blue-500">End Date</th>
                                        <th class="py-2 px-4 border border-blue-500">Remaining Days</th>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create amount')): ?>
                                            <th class="py-2 px-4 border border-blue-500">Status</th>
                                            <th class="py-2 px-4 border border-blue-500">Delete</th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody id="advert-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $estates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e($estate->id); ?></td>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e($estate->estateAdvert->estate); ?></td>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e($estate->landlord_id); ?></td>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e($estate->price); ?></td>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e($estate->txn_ref); ?></td>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e($estate->created_at); ?></td>
                                                <?php
                                                    // Calculate the difference in days
                                                    $startDate = \Carbon\Carbon::parse($estate->created_at);
                                                    $nowDate = \Carbon\Carbon::now();
                                                    $oneMonthLater = $startDate->copy()->addMonths(1);                    
                                                    $daysLeft = $oneMonthLater->diffInDays($nowDate);
                                                ?>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e($oneMonthLater); ?></td>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e($daysLeft); ?></td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create amount')): ?>
                                                    <td class="py-2 px-3 border-b border-r">
                                                        <a href="<?php echo e(route('advert.status',$estate->id)); ?>" class="py-1 px-2 
                                                            <?php echo e($estate->status == 0 ? 'bg-green-300' : 'bg-red-300'); ?> 
                                                            text-white rounded hover:<?php echo e($estate->status == 0 ? 'bg-green-500' : 'bg-red-500'); ?>">
                                                            <?php echo e($estate->status == 0 ? 'Running' : 'Inactive'); ?>

                                                        </a>
                                                    </td>
                                                    <td class="py-2 px-3 border-b border-r">
                                                        <a href="<?php echo e(route('advert.destroy',$estate->id)); ?>" class="py-1 px-2 bg-red-300
                                                            text-white rounded hover:bg-red-500">
                                                            Delete
                                                        </a>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <td class="py-2 px-4 border-b border-r"><?php echo e(__('No Advert Available')); ?></td>
                                        <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        </div>
                    </div>

                    <!-- unit table -->
                    <div class="table-responsive" style="overflow-x: auto;">
                        <div class="container mx-auto mt-8">
                            <input type="text" class="rounded text-gray-500" id="unitSearch" placeholder="Search Unit Subs">
                            <button onclick="hideTable2()" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                                &times;Hide
                            </button>
                            <button class="bg-green-500 text-white font-bold py-2 px-4 rounded">
                                Total Amount: <?php echo e($total_units); ?>

                            </button>
                            <table class="min-w-full border border-blue-500 text-gray-500" id="unitpayTable">
                                <thead>
                                    <tr>
                                        <th class="py-2 px-4 border border-blue-500">ID</th>
                                        <th class="py-2 px-4 border border-blue-500">Estate Name</th>
                                        <th class="py-2 px-4 border border-blue-500">Landlord</th>
                                        <th class="py-2 px-4 border border-blue-500">Amount</th>
                                        <th class="py-2 px-4 border border-blue-500">Transaction Id</th>
                                        <th class="py-2 px-4 border border-blue-500">Start Date</th>
                                        <th class="py-2 px-4 border border-blue-500">End Date</th>
                                        <th class="py-2 px-4 border border-blue-500">Remaining Days</th>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create amount')): ?>
                                            <th class="py-2 px-4 border border-blue-500">Status</th>
                                            <th class="py-2 px-4 border border-blue-500">Delete</th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody id="unit-list">
                                    <?php $__empty_1 = true; $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e($unit->id); ?></td>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e($unit->estateUnitpay->estate); ?></td>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e($unit->landlord_id); ?></td>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e($unit->amount); ?></td>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e($unit->txn_ref); ?></td>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e($unit->created_at); ?></td>
                                                <?php
                                                    // Calculate the difference in days
                                                    $startDate = \Carbon\Carbon::parse($unit->created_at);
                                                    $nowDate = \Carbon\Carbon::now();
                                                    $oneMonthLater = $startDate->copy()->addMonths(1);                    
                                                    $daysLeft = $oneMonthLater->diffInDays($nowDate);
                                                ?>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e($oneMonthLater); ?></td>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e($daysLeft); ?></td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create amount')): ?>
                                                    <td class="py-2 px-3 border-b border-r">
                                                        <a href="<?php echo e(route('unitpay.status',$unit->id)); ?>" class="py-1 px-2 
                                                            <?php echo e($unit->status == 1 ? 'bg-green-300' : 'bg-red-300'); ?> 
                                                            text-white rounded hover:<?php echo e($unit->status == 1 ? 'bg-green-500' : 'bg-red-500'); ?>">
                                                            <?php echo e($unit->status == 1 ? 'Running' : 'Inactive'); ?>

                                                        </a>
                                                    </td>
                                                    <td class="py-2 px-3 border-b border-r">
                                                        <a href="<?php echo e(route('unitpay.destroy',$unit->id)); ?>" class="py-1 px-2 bg-red-300
                                                            text-white rounded hover:bg-red-500">
                                                            Delete
                                                        </a>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <td class="py-2 px-4 border-b border-r"><?php echo e(__('No Unit Available')); ?></td>
                                        <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<script>
    function hideTable() {
        const table = document.getElementById('advertTable');
        if (table) {
            if (table.style.display === 'none') {
                table.style.display = ''; 
            } else {
                table.style.display = 'none';
            }
        }
    }

    // Get the input element and table body
    const searchInput = document.getElementById('advertSearch');
    const advertTableBody = document.getElementById('advert-list');
    // Add event listener to the search input
    searchInput.addEventListener('input', function () {
        const searchValue = this.value.toLowerCase().trim();
        const rows = advertTableBody.getElementsByTagName('tr');

        // Loop through all table rows to check for matches and display/hide accordingly
        for (let row of rows) {
            const estateName = row.getElementsByTagName('td')[1]; // District name column index
            const tran_ref = row.getElementsByTagName('td')[4]; // Country name column index

            if (tran_ref && estateName) {
                const textEstate = estateName.textContent || estateName.innerText;
                const textTrans = tran_ref.textContent || tran_ref.innerText;

                if (
                    textEstate.toLowerCase().includes(searchValue) ||
                    textTrans.toLowerCase().includes(searchValue)
                ) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        }
    });


    function hideTable2() {
        const table = document.getElementById('unitpayTable');
        if (table) {
            if (table.style.display === 'none') {
                table.style.display = ''; 
            } else {
                table.style.display = 'none';
            }
        }
    }

    // Get the input element and table body
    const searchInputUnit = document.getElementById('unitSearch');
    const unitTableBody = document.getElementById('unit-list');
    // Add event listener to the search input
    searchInputUnit.addEventListener('input', function () {
        const searchUnit = this.value.toLowerCase().trim();
        const rowsUnit = unitTableBody.getElementsByTagName('tr');

        // Loop through all table rows to check for matches and display/hide accordingly
        for (let row of rowsUnit) {
            const estateName = row.getElementsByTagName('td')[1]; // District name column index
            const tran_ref = row.getElementsByTagName('td')[4]; // Country name column index

            if (tran_ref && estateName) {
                const textEstate = estateName.textContent || estateName.innerText;
                const textTrans = tran_ref.textContent || tran_ref.innerText;

                if (
                    textEstate.toLowerCase().includes(searchUnit) ||
                    textTrans.toLowerCase().includes(searchUnit)
                ) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        }
    });
</script><?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/dashboard/income.blade.php ENDPATH**/ ?>