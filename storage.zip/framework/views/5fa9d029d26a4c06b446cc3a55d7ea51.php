<?php echo $__env->make('dashboard.tenant-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Units')); ?> 
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg table-responsive"  style="overflow-x: auto;">
                <div class="max-w-7xl mx-auto p-6">
                    <input type="text" id="estateSearch" class="rounded text-gray-500 mb-4" placeholder="Search Estate">
                    <div class="flex space-x-4" id="estateContainer">
                        <?php $__empty_1 = true; $__currentLoopData = $estates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if(auth()->user()->role == 'Admin' || auth()->user()->id == $estate->landlord_id || auth()->user()->id == $estate->broker_id): ?>
                                    <button class="bg-blue-500 active:bg-red-700 text-white px-4 py-2 rounded hover:bg-0" onclick="showContent('<?php echo e($estate->uid); ?>')"><?php echo e($estate->estate); ?></button>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h2 class="text-xl font-bold mb-2">No Estate Registered</h2>
                        <?php endif; ?>
                    </div>
                    <h4>  
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => ['class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>  
                        <?php if(session('error')): ?>
                            <span class="bg-red-500 text-white rounded">
                                <?php echo e(session('error')); ?>

                            </span>
                        <?php endif; ?>
                        <?php if(session('success')): ?>
                            <span class="bg-green-500 text-white rounded">
                                <?php echo e(session('success')); ?>

                            </span>
                        <?php endif; ?>
                    </h4>
                    <?php $counter = 0; ?>
                    <?php $formCounter = 0; ?>
                    <?php $editCounter= 0; ?>
                    <?php $searchCounter= 0; ?>
                    <?php $__empty_1 = true; $__currentLoopData = $estates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="hidden mt-4 border-b border-gray-200 py-3" id="content_<?php echo e($estate->uid); ?>">
                                <div class="grid grid-cols-1 border-b border-gray-200 py-3 gap-4">
                                    <h2 class="text-2xl font-bold mb-4"><?php echo e($estate->estate); ?></h2>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create unit')): ?>
                                        <div class="p-4 rounded-lg shadow-md">
                                            <button onclick="hideTable(<?php echo e($counter); ?>)" class="bg-green-500 text-white px-3 py-1 rounded-sm text-sm">
                                                Toggle Unit
                                            </button>
                                            <?php echo $__env->make('units.create-unit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php $counter++; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="grid grid-cols-1  w-1/3 rounded">
                                    <input type="text" class="unit-search rounded text-gray-500 mb-4" data-estate="<?php echo e($estate->uid); ?>" placeholder="Search Unit Name">
                                </div>
                                <?php $__empty_2 = true; $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                    <?php if($estate->uid == $unit->estate_uid): ?>
                                    <div class="unit-container" style="display: block;" data-estate-id="<?php echo e($estate->uid); ?>">
                                        <h2 class="text-xl font-bold mb-4 flex justify-center"><?php echo e($unit->unit); ?></h2>
                                        <?php echo $__env->make('units.edit-unit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <div class="space-x-2 mb-2 grid grid-cols-1 md:grid-cols-2 gap-4">
                                            <div class="flex flex-col md:flex-row">
                                                <div class="bg-gray-100 p-4 rounded-lg shadow-md mr-4 table-responsive" style="overflow-x: auto;">
                                                    <h2 class="text-xl font-bold mb-2">Unit Information (Part 1)</h2>
                                            
                                                    <!-- Unit Name and Estate Name -->
                                                    <div class="mb-4">
                                                        <p class="text-lg font-semibold">Unit Name: <span class="text-gray-700"><?php echo e($unit->unit); ?></span></p>
                                                        <p class="text-lg font-semibold">Estate Name: <span class="text-gray-700"><?php echo e($estate->estate); ?></span></p>
                                                    </div>

                                                    <!-- Client Name -->
                                                    <div class="mb-4">
                                                        <p class="text-lg font-semibold">Client Name: 
                                                            <span class="text-gray-700">
                                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($unit->tenant_id == $user->id): ?>
                                                                        <?php echo e($user->name); ?>

                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </span>
                                                        </p>
                                                    </div>

                                                    <!-- Lease Duration -->
                                                    <div class="mb-4">
                                                        <p class="text-lg font-semibold">Lease Start: <span class="text-gray-700"><?php echo e($unit->lease_start); ?></span></p>
                                                        <p class="text-lg font-semibold">Lease End: <span class="text-gray-700"><?php echo e($unit->lease_stop); ?></span></p>
                                                        <p class="text-lg font-semibold">Lease Status: <span class="text-gray-700">
                                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create unit')): ?>
                                                            <a href="<?php echo e(route('unit.status', $unit)); ?>" class="py-1 px-2 
                                                                <?php echo e($unit->status == 1 ? 'bg-green-300 text-white hover:bg-green-500' : 'bg-red-300 text-white hover:bg-red-500'); ?> 
                                                                rounded">
                                                                <?php echo e($unit->status == 1 ? 'Occupied' : 'Unoccupied'); ?>

                                                            </a>
                                                            </span></p>
                                                        <?php endif; ?>
                                                    </div>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create unit')): ?>
                                                        <button onclick="toggleFormVisibility(<?php echo e($formCounter); ?>)" class="bg-green-500 text-white px-3 py-1 rounded-sm text-sm">
                                                            Update Tenant
                                                        </button>
                                                    <?php endif; ?>
                                                </div>

                                                <!-- Form on the right-hand side -->
                                                <div class="bg-gray-100 p-4 rounded-lg shadow-md hidden" id="form<?php echo e($formCounter); ?>">
                                                    <h4 class="text-xl font-bold mb-2">Update Tenant</h4>
                                                    <form method="POST" action="<?php echo e(route('update.tenant')); ?>" enctype="multipart/form-data">
                                                        <?php echo csrf_field(); ?>
                                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['id' => 'estate_id','class' => 'w-4/5 px-2 py-1 rounded text-gray-700','type' => 'hidden','name' => 'unit_id','value' => ''.e($unit->id).'','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'estate_id','class' => 'w-4/5 px-2 py-1 rounded text-gray-700','type' => 'hidden','name' => 'unit_id','value' => ''.e($unit->id).'','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['id' => 'estate_uid','class' => 'w-4/5 px-2 py-1 rounded text-gray-700','type' => 'hidden','name' => 'unit_uid','value' => ''.e($unit->uid).'','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'estate_uid','class' => 'w-4/5 px-2 py-1 rounded text-gray-700','type' => 'hidden','name' => 'unit_uid','value' => ''.e($unit->uid).'','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                                        
                                                        <div class="mt-6">
                                                            <label for="lease_start" class="font-semibold">Lease Start:</label>
                                                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['id' => 'lease_start','class' => 'w-4/5 px-2 py-1 rounded text-gray-700','type' => 'date','name' => 'lease_start','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'lease_start','class' => 'w-4/5 px-2 py-1 rounded text-gray-700','type' => 'date','name' => 'lease_start','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                                        </div>

                                                        <div class="mt-6">
                                                            <label for="lease_stop" class="font-semibold">Lease Stop:</label>
                                                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input','data' => ['id' => 'lease_stop','class' => 'w-4/5 px-2 py-1 rounded text-gray-700','type' => 'date','name' => 'lease_stop','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'lease_stop','class' => 'w-4/5 px-2 py-1 rounded text-gray-700','type' => 'date','name' => 'lease_stop','required' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
                                                        </div>

                                                        <div class="mt-6">
                                                            <label for="tenant_id" class="font-semibold">Type Tenant Email:</label>
                                                            <select id="tenant_id" class="w-4/5 px-2 py-1 rounded text-gray-700" name="tenant_id" required>
                                                                <option class="block mt-1 w-full" value=""></option>
                                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <option class="block mt-1 w-full" value="<?php echo e($user->id); ?>"><?php echo e($user->email); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        
                                                        <div class="mt-6">
                                                            <button type="submit" class="bg-red-700 text-white px-3 py-1 rounded-sm text-sm">
                                                                Submit
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                                <?php $formCounter++; ?>
                                            </div>
                                            
                                            <div class="bg-gray-100 p-4 rounded-lg shadow-md">
                                                <h2 class="text-xl font-bold mb-2">Unit Information (Part 2)</h2>

                                                <?php
                                                    // Calculate the difference in days
                                                    $nowDate = \Carbon\Carbon::now();
                                                    $endDate = \Carbon\Carbon::parse($unit->lease_stop);
                                                    $daysLeft = $nowDate->diffInDays($endDate);
                                                ?>
                                                <div class="mb-4">
                                                    <p class="text-lg font-semibold">Terms & Conditions: 
                                                        <span class="text-gray-700">
                                                        <?php if($unit->sponsored == 0): ?>
                                                            <span class="text-red-500"><?php echo e(__('Unaccepted Yet')); ?></span>
                                                        <?php else: ?>
                                                            <span class="text-green-500"><?php echo e(__('Accepted')); ?></span>
                                                        <?php endif; ?>
                                                        </span>
                                                    </p>
                                                    <p class="text-lg font-semibold">Number of Days Left: <span class="text-gray-700"><?php echo e($daysLeft); ?></span></p>
                                                </div>

                                                <!-- Details: Bedrooms, Bathrooms, Square Foot -->
                                                <div class="mb-4">
                                                    <p class="text-lg font-semibold">Rooms: <span class="text-gray-700"><?php echo e($unit->room_no); ?></span></p>
                                                    <p class="text-lg font-semibold">Square Foot: <span class="text-gray-700"><?php echo e($unit->square_footage); ?></span></p>
                                                </div>

                                                <!-- Price and Rooms -->
                                                <div class="mb-4">
                                                    <p class="text-lg font-semibold">Price: <span class="text-gray-700"><?php echo e($unit->price); ?>/<?php echo e($unit->durationName->duration); ?></span></p>
                                                    <p class="text-lg font-semibold">Room Description: <span class="text-gray-700"><?php echo e($unit->description); ?></span></p>
                                                </div>

                                                <!-- Essential Resources -->
                                                <div>
                                                    <p class="text-lg font-semibold">Essential Resources: <span class="text-gray-700">
                                                        <?php
                                                            $resourcesArray = json_decode($unit->resources);
                                                        ?>
                                                        <?php echo e(is_array($resourcesArray) ? implode(', ', $resourcesArray) : $unit->resources); ?>

                                                    </span></p>
                                                </div>
                                                
                                                <button onclick="toggleEditForm(<?php echo e($editCounter); ?>, <?php echo e(json_encode($unit)); ?>)" class="bg-green-500 text-white px-3 py-1 rounded-sm text-sm">
                                                    Edit Unit
                                                </button>
                                                <?php $editCounter++; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                    <h2 class="text-xl font-bold mb-2">No Estate Unit Registered</h2>
                                <?php endif; ?>
                        </div>
                        <?php $searchCounter++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h2 class="text-xl font-bold mb-2">No Estate Registered</h2>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<script>
    function showContent(sectionId) {
        const sections = document.querySelectorAll('[id^="content_"]');
        sections.forEach(section => {
            if (section.id === `content_${sectionId}`) {
                section.classList.toggle('hidden');
            } else {
                section.classList.add('hidden');
            }
        });
    }

    
    function hideTable(index) {
        var unitForm = document.getElementById("unitForm" + index);
        if (unitForm.style.display !== "none") {
            unitForm.style.display = "none";
        } else {
            unitForm.style.display = "block";
        }
    }

    function toggleFormVisibility(counter) {
        var form = document.getElementById("form" + counter);
        form.classList.toggle("hidden");
    }

    document.addEventListener("DOMContentLoaded", function() {
        const searchInputs = document.querySelectorAll('.unit-search');

        searchInputs.forEach(input => {
            input.addEventListener('input', function() {
                const estateId = this.getAttribute('data-estate');
                const searchText = this.value.toLowerCase();
                filterUnits(estateId, searchText);
            });
        });

        function filterUnits(estateId, searchText) {
            const units = document.querySelectorAll(`.unit-container[data-estate-id='${estateId}']`);

            units.forEach(unit => {
                const unitName = unit.querySelector('h2').textContent.toLowerCase();
                const displayStyle = unitName.includes(searchText) ? 'block' : 'none';
                unit.style.display = displayStyle;
            });
        }
    });

    
    // Function to handle estate filtering based on search query
    function filterEstates() {
        const searchText = document.getElementById('estateSearch').value.toLowerCase();
        const estateButtons = document.querySelectorAll('#estateContainer button');
        
        estateButtons.forEach(button => {
            const estateName = button.textContent.toLowerCase();
            
            if (estateName.includes(searchText)) {
                button.style.display = 'block'; 
            } else {
                button.style.display = 'none'; 
            }
        });
    }
    document.getElementById('estateSearch').addEventListener('input', filterEstates);
</script>
<?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/units/index.blade.php ENDPATH**/ ?>