<a href="/">
    <img src="<?php echo e(asset('frontend/images/logo.png')); ?>" alt="logo" style="height: 40px; width: 120px;"/>
</a><?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/components/application-mark.blade.php ENDPATH**/ ?>