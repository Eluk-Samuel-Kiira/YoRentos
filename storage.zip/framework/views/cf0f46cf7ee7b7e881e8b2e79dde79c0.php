<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<title>Estate | YoRentos</title>
<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if($estate): ?>
    <section class="about_section layout_padding">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3 class="btn uppercase font-size">
                        <b>
                            <?php echo e($estate->estate); ?>

                        </b>
                    </h3>
                    <div class="img-box">
                        <img src="<?php echo e(asset('frontend/images/about-img.jpg')); ?>" alt="" id="displayedImage">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="detail-box">
                        <div class="slider-container">
                            <div class="slider">
                                <?php if($estate->images): ?>
                                    <?php $__currentLoopData = explode(',', $estate->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="small">  
                                            <img src="<?php echo e(asset('storage/estate_images/' . $estate->landlord_id . '/' . $imageName)); ?>" alt="" onclick="displayImage(this)">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div class="small">  
                                        <img src="<?php echo e(asset('frontend/images/s-2.jpg')); ?>" alt="" onclick="displayImage(this)">
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <p>
                            <div class="container-header">
                                <h2 class="rental_heading">
                                    About Our <?php echo e($estate->rentalName->name); ?>

                                </h2>
                            </div>
                            <h6 style="font-family: Arial, sans-serif;">
                                <?php echo e($estate->description); ?>

                            </h6>
                            <div class="btn-box">
                                <a href="<?php echo e(route('rental.map', $estate)); ?>">
                                    Navigate To Us
                                </a>
                            </div>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="about_section layout_padding">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <?php if($estate->video): ?>
                        <div class="container-header">
                            <h2 class="rental_heading">
                                About Our <?php echo e($estate->rentalName->name); ?>

                            </h2>
                        </div>
                        <video controls style="width: 100%; height: 240px;">
                            <source src="<?php echo e(asset('storage/estate_videos')); ?>/<?php echo e($estate->video); ?>" type="video/mp4" id="displayedImage">
                            Your browser does not support the video tag.
                        </video>
                    <?php endif; ?>
                </div>
                <div class="col-md-8"><br>
                    <div class="container-header">
                        <h2 class="rental_heading">
                            Other Important Details
                        </h2>
                    </div>
                    <div class="about-details custom-styling">
                        <h6><br>
                            <span class="btn btn-small price-range">
                                <?php
                                    $minPrice = $estate->unitEstate->min('price');
                                    $maxPrice = $estate->unitEstate->max('price');
                                ?>
                                <?php echo e(__('Price Range: ')); ?>

                                <?php if($minPrice !== null && $maxPrice !== null): ?>
                                    <?php echo e($minPrice); ?> - <?php echo e($maxPrice); ?>

                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            </span>
                            <span class="btn btn-small available-units">
                                <?php
                                    $availableUnits = $estate->unitEstate->where('status', 0)->count();
                                    $allUnits = $estate->unitEstate->count();
                                ?>
                                <?php echo e(__('Units Available: ')); ?>

                                <?php if($availableUnits !== 0): ?> 
                                    <?php echo e($availableUnits); ?>/<?php echo e($allUnits); ?>

                                <?php else: ?>
                                    <?php echo e(__('NONE')); ?>

                                <?php endif; ?>
                            </span>
                            <span class="btn btn-small village">
                                <?php echo e(__('Village:  ')); ?>

                                <img src="<?php echo e(asset('frontend/images/location.png')); ?>" width="10px" style="display: inline-block; vertical-align: middle; margin-right: 5px;" alt="">
                                <?php echo e($estate->villageEstate->village); ?>

                            </span>
                            <span class="btn btn-small reviews">
                                <?php echo e($estate->unit_no); ?><?php echo e(__(' Reviews')); ?>

                            </span>
                            <span class="btn btn-small">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($estate->landlord_id == $user->id): ?>
                                        <?php echo e(__('Officials: ')); ?><?php echo e($user->name); ?> <br>
                                        <?php echo e(__('Telephone: ')); ?><?php echo e($user->phone_number); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </span>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($estate->broker_id == $user->id): ?> 
                                    <div style="height: 160px; width: 160px;">
                                        <img src="<?php echo e($user->profile_photo_url); ?>" alt="">
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <span class="btn btn-small">
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($estate->broker_id == $user->id): ?>
                                        <?php echo e(__('Trusted Broker: ')); ?><?php echo e($user->name); ?> <br>
                                        <?php echo e(__('Telephone: ')); ?><?php echo e($user->phone_number); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </span>
                        </h6>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="price_section layout_padding-bottom">
        <div class="container">
            <div class="heading_container">
                <h2>
                    Our Units
                </h2>
                <p>
                    There are many variations of our rooms, below are the ones <b>AVAILABLE or UNOCCUPIED.</b>
                </p>
            </div>
            <div class="price_container">
                <?php
                    $totalRooms = count($estate->unitEstate);
                    $occupiedRooms = $estate->unitEstate->where('status', 1)->count();
                    $availableRooms = $totalRooms - $occupiedRooms;
                ?>

                <?php if($availableRooms == 0): ?>
                    <div class="btn-box">
                        <?php echo e(__('No Room/Unit Available')); ?>

                    </div>
                <?php elseif($totalRooms == 0): ?>
                    <div class="btn-box">
                        <?php echo e(__('No Unit Registered As Yet')); ?>

                    </div>
                <?php else: ?>
                    <?php $__currentLoopData = $estate->unitEstate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($unit->status == 0): ?>
                            <div class="box">
                                <div class="detail-box">
                                    <div class="heading-box">
                                        <h6>
                                            <?php echo e($unit->unit); ?>

                                        </h6>
                                    </div>
                                    <div class="text-box">
                                        <h2>
                                            <?php echo e($unit->price); ?>

                                        </h2>
                                        <ul>
                                            <li>
                                                <?php echo e($unit->rentalName->name); ?>

                                            </li>
                                            <li>
                                                <?php echo e($unit->durationName->duration); ?>

                                            </li>
                                            <li>
                                                <?php echo e($unit->square_footage); ?>

                                            </li>
                                            <span>
                                                <li>
                                                    <?php echo e($unit->description); ?>

                                                </li>
                                                <li>
                                                    <?php
                                                        $resourcesArray = json_decode($unit->resources);
                                                    ?>
                                                    <?php echo e(is_array($resourcesArray) ? implode(', ', $resourcesArray) : $unit->resources); ?>

                                                </li>
                                                <li>
                                                    <?php echo e(__('Unoccupied')); ?>

                                                </li>
                                            </span>
                                        </ul>
                                    </div>
                                </div>
                                <!-- <div class="btn-box">
                                    <a href="">
                                        Book Now
                                    </a>
                                </div> -->
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php endif; ?>

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    function displayImage(element) {
        var clickedImageSrc = element.src;
        var displayedImage = document.getElementById('displayedImage');
        displayedImage.src = clickedImageSrc;
    }
</script><?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/tenant/estate-unit.blade.php ENDPATH**/ ?>