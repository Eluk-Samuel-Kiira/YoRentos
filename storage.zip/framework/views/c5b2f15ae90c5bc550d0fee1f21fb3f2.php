<?php echo $__env->make('dashboard.tenant-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.not-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Parishes/Wards and Villages')); ?> 
        </h2>
     <?php $__env->endSlot(); ?>
    <?php if(\Spatie\Permission\PermissionServiceProvider::bladeMethodWrapper('hasRole', 'Admin')): ?>
        <div class="py-12">
            <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
                <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                    <div class="max-w-7xl mx-auto p-6">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage all')): ?>
                            <button id="openParishModal" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                Add Parish
                            </button>
                            <button id="openVillageModal" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                                Add Village
                            </button>
                        <?php endif; ?>
                        <h4>  
                            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => ['class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>  
                            <?php if(session('error')): ?>
                                <span class="bg-red-500 text-white rounded">
                                    <?php echo e(session('error')); ?>

                                </span>
                            <?php endif; ?>
                            <?php if(session('success')): ?>
                                <span class="bg-green-500 text-white rounded">
                                    <?php echo e(session('success')); ?>

                                </span>
                            <?php endif; ?>
                        </h4>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage all')): ?>
                            <!-- Parishes table -->
                            <div class="table-responsive" style="overflow-x: auto;">
                                <div class="container mx-auto mt-8" id="parishTable">
                                    <input type="text" class="rounded text-gray-500" id="parishSearch" placeholder="Search SubCounty or parish">
                                    <button class="bg-green-500 text-white font-bold py-2 px-4 rounded">
                                        <?php echo e($parishes->count()); ?> <?php echo e(__('Parishes')); ?>

                                    </button>
                                    <button onclick="hideTable()" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                                        &times;Hide
                                    </button>
                                    <table class="min-w-full border border-blue-500 text-gray-500">
                                        <?php echo $__env->make('parishes.create-parish', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <thead>
                                            <tr>
                                                <th class="py-2 px-4 border border-blue-500">ID</th>
                                                <th class="py-2 px-4 border border-blue-500">Parish</th>
                                                <th class="py-2 px-4 border border-blue-500">Subcounty/Division</th>
                                                <th class="py-2 px-4 border border-blue-500">Status</th>
                                                <th class="py-2 px-4 border border-blue-500">Edit</th>
                                            </tr>
                                        </thead>
                                        <tbody id="parishTableBody">
                                            <?php $__empty_1 = true; $__currentLoopData = $parishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td class="py-2 px-4 border-b border-r"><?php echo e($parish->uid); ?></td>
                                                    <td class="py-2 px-4 border-b border-r"><?php echo e($parish->parish); ?></td>
                                                    <td class="py-2 px-4 border-b border-r"><?php echo e($parish->subcountyName->subcounty); ?></td>
                                                    <td class="py-2 px-3 border-b border-r">
                                                        <a href="<?php echo e(route('parish.status',$parish)); ?>" class="py-1 px-2 
                                                            <?php echo e($parish->status == 1 ? 'bg-green-300' : 'bg-red-300'); ?> 
                                                            text-white rounded hover:<?php echo e($parish->status == 1 ? 'bg-green-500' : 'bg-red-500'); ?>">
                                                            <?php echo e($parish->status == 1 ? 'Active' : 'Inactive'); ?>

                                                        </a>
                                                    </td>
                                                    <td class="py-2 px-4 border-b border-r">
                                                        <a href="#" onclick="openParishModal(<?php echo e(json_encode($parish)); ?>)" class="py-1 px-2 bg-blue-300 text-white rounded hover:bg-blue-500">
                                                            <?php echo e(__('Edit')); ?>

                                                        </a>
                                                    </td>
                                                    <?php echo $__env->make('parishes.edit-parish', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e(__('No Parish Available')); ?></td>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>

                            <!-- villages table -->
                            <div class="table-responsive" style="overflow-x: auto;" >
                                <div class="container mx-auto mt-8" id="villageTable">
                                    <input type="text" class="rounded text-gray-500" id="villageSearch" placeholder="Search parish or village">
                                    <button class="bg-green-500 text-white font-bold py-2 px-4 rounded">
                                        <?php echo e($villages->count()); ?> <?php echo e(__('Villages')); ?>

                                    </button>
                                    <button onclick="hideTable2()" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                                        &times;Hide
                                    </button>
                                    <table class="min-w-full border border-blue-500 text-gray-500">
                                        <?php echo $__env->make('parishes.create-village', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <thead>
                                            <tr>
                                                <th class="py-2 px-4 border border-blue-500">ID</th>
                                                <th class="py-2 px-4 border border-blue-500">Village</th>
                                                <th class="py-2 px-4 border border-blue-500">Parish</th>
                                                <th class="py-2 px-4 border border-blue-500">Status</th>
                                                <th class="py-2 px-4 border border-blue-500">Edit</th>
                                            </tr>
                                        </thead>
                                        <tbody id="villageTableBody">
                                            <?php $__empty_1 = true; $__currentLoopData = $villages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $village): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td class="py-2 px-4 border-b border-r"><?php echo e($village->uid); ?></td>
                                                    <td class="py-2 px-4 border-b border-r"><?php echo e($village->village); ?></td>
                                                    <td class="py-2 px-4 border-b border-r"><?php echo e($village->parishName->parish); ?></td>
                                                    <td class="py-2 px-3 border-b border-r">
                                                        <a href="<?php echo e(route('village.status',$village)); ?>" class="py-1 px-2 
                                                            <?php echo e($village->status == 1 ? 'bg-green-300' : 'bg-red-300'); ?> 
                                                            text-white rounded hover:<?php echo e($village->status == 1 ? 'bg-green-500' : 'bg-red-500'); ?>">
                                                            <?php echo e($village->status == 1 ? 'Active' : 'Inactive'); ?>

                                                        </a>
                                                    </td>
                                                    <td class="py-2 px-4 border-b border-r">
                                                        <a href="#" onclick="openVillageModal(<?php echo e(json_encode($village)); ?>)" class="py-1 px-2 bg-blue-300 text-white rounded hover:bg-blue-500">
                                                            <?php echo e(__('Edit')); ?>

                                                        </a>
                                                    </td>
                                                    <?php echo $__env->make('parishes.edit-village', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e(__('No Village Available')); ?></td>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<script>

    // // Get the input element and table body
    const searchInputParish = document.getElementById('parishSearch');
    const tableBodyParish = document.getElementById('parishTableBody');

    // Add event listener to the search input
    searchInputParish.addEventListener('input', function () {
        const searchValueParish = this.value.toLowerCase().trim();
        const rowsParish = tableBodyParish.getElementsByTagName('tr');

        // Loop through all table rows to check for matches and display/hide accordingly
        for (let row of rowsParish) {
            const parishName = row.getElementsByTagName('td')[1]; // District name column index
            const subcountytName = row.getElementsByTagName('td')[2]; // Country name column index

            if (subcountytName && parishName) {
                const textParish = parishName.textContent || parishName.innerText;
                const textSubcounty = subcountytName.textContent || subcountytName.innerText;

                if (
                    textParish.toLowerCase().includes(searchValueParish) ||
                    textSubcounty.toLowerCase().includes(searchValueParish)
                ) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        }
    });

    // Get the input element and table body
    const searchInputVillage = document.getElementById('villageSearch');
    const villagetableBody = document.getElementById('villageTableBody');

    // Add event listener to the search input
    searchInputVillage.addEventListener('input', function () {
        const searchValueVillage = this.value.toLowerCase().trim();
        const rowsVillage = villagetableBody.getElementsByTagName('tr');

        // Loop through all table rows to check for matches and display/hide accordingly
        for (let row of rowsVillage) {
            const villageName = row.getElementsByTagName('td')[1]; // District name column index
            const parishName = row.getElementsByTagName('td')[2]; // Country name column index

            if (parishName && villageName) {
                const textVillage = villageName.textContent || villageName.innerText;
                const textParish = parishName.textContent || parishName.innerText;

                if (
                    textVillage.toLowerCase().includes(searchValueVillage) ||
                    textParish.toLowerCase().includes(searchValueVillage)
                ) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        }
    });

    function hideTable() {
        const table = document.getElementById('parishTable');
        if (table) {
            table.style.display = 'none';
        }
    }

    function hideTable2() {
        const table = document.getElementById('villageTable');
        if (table) {
            table.style.display = 'none';
        }
    }
</script><?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/parishes/index.blade.php ENDPATH**/ ?>