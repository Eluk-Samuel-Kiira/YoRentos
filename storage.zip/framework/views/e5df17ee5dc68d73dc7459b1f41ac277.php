<?php if(auth()->user()->deleted != 1): ?>
    <script>
        window.location.href = "<?php echo e(route('account.confirm')); ?>";
    </script>
<?php elseif(auth()->user()->status != 1): ?>
    <script>
        window.location.href = "<?php echo e(route('account-deactivate')); ?>";
    </script>
<?php endif; ?><?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/dashboard/not-admin.blade.php ENDPATH**/ ?>