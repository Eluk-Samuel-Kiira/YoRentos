<?php echo $__env->make('dashboard.tenant-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Estates')); ?> 
        </h2>
        <h6>
            <div id="error-container"></div>
        </h6>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg  table-responsive"  style="overflow-x: auto;">
                <div class="max-w-7xl mx-auto p-6">
                    <input type="text" id="estateSearch" class="rounded text-gray-500 mb-4" placeholder="Search Estate">
                    <div class="flex space-x-4" id="estateContainer">
                        <?php $__empty_1 = true; $__currentLoopData = $estates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if(auth()->user()->role == 'Admin' || auth()->user()->id == $estate->landlord_id || auth()->user()->id == $estate->broker_id): ?>
                                <button class="bg-blue-500 active:bg-red-700 text-white px-4 py-2 rounded hover:bg-0" onclick="showContent('<?php echo e($estate->uid); ?>')"><?php echo e($estate->estate); ?></button>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <h2 class="text-xl font-bold mb-2">No Estate Registered</h2>
                        <?php endif; ?>
                    </div>
                    <h4>  
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => ['class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>  
                        <?php if(session('error')): ?>
                            <span class="bg-red-500 text-white rounded">
                                <?php echo e(session('error')); ?>

                            </span>
                        <?php endif; ?>
                        <?php if(session('success')): ?>
                            <span class="bg-green-500 text-white rounded">
                                <?php echo e(session('success')); ?>

                            </span>
                        <?php endif; ?>
                    </h4>
                    <?php $__empty_1 = true; $__currentLoopData = $estates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div id="content_<?php echo e($estate->uid); ?>" class="hidden mt-4">
                            <h2 class="text-2xl font-bold mb-4"><?php echo e($estate->estate); ?></h2>
                            <div class="border-b border-gray-200 py-3">
                                <div class="flex flex-col md:flex-row md:items-center md:justify-between">
                                    <div> 
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($estate->landlord_id == $user->id): ?>
                                                <p class="text-lg font-semibold">Landlord: <?php echo e($user->name); ?></p>
                                                <p class="text-sm text-gray-500">Email: <?php echo e($user->email); ?></p>
                                                <p class="text-sm text-gray-500">Phone: <?php echo e($user->phone_number); ?></p>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($estate->broker_id == $user->id): ?>
                                                <p class="text-lg font-semibold">Broker: <?php echo e($user->name); ?></p>
                                                <p class="text-sm text-gray-500">Email: <?php echo e($user->email); ?></p>
                                                <p class="text-sm text-gray-500">Phone: <?php echo e($user->phone_number); ?></p>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Subscribe details -->
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create estate')): ?>
                                <div class="border-b border-gray-200 py-3">
                                    <div class="flex justify-between items-center">
                                        <h3 class="text-lg font-semibold mb-2">Pricing:</h3>
                                        <div class="inline-block p-1">
                                            <button onclick="toggleAdvert('<?php echo e($estate->uid); ?>')" class="bg-blue-500 text-white px-2 py-1 rounded-sm text-xs hover:bg-blue-600 motion-reduce:transform-none">
                                                Advertise Estate
                                            </button>
                                        </div>
                                        <div class="inline-block p-1">
                                            <button onclick="toggleUnits('<?php echo e($estate->uid); ?>')" class="bg-blue-500 text-white px-2 py-1 rounded-sm text-xs hover:bg-blue-600 motion-reduce:transform-none">
                                                Subscribe Units
                                            </button>
                                        </div>
                                    </div> 
                                        
                                    <div class="md:flex">
                                        <?php echo $__env->make('estates.advertise-estate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <?php echo $__env->make('estates.pay-unit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        <div class="w-full md:w-1/3 bg-gray-200 rounded-lg p-2 mt-4 md:mt-0">
                                            <div class="w-full bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                                                <div class="flex flex-col space-y-4">
                                                    <div>
                                                        <p class="text-lg font-semibold">Advert Status</p>
                                                        <?php if($estate->sponsored == 1): ?>
                                                            <p class="text-sm text-gray-500 flex items-center">
                                                                <span class="py-1 px-2 bg-green-300 text-white rounded">Advert is Still Running</span>
                                                            </p>
                                                        <?php else: ?>
                                                            <p class="text-sm text-gray-500 flex items-center">
                                                                <span class="py-1 px-2 bg-red-300 text-white rounded">Advert is Off</span>
                                                            </p>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div>
                                                        <p class="text-lg font-semibold">Units Access Status</p>
                                                        <?php if($estate->paidUnit->contains('status', 1)): ?>
                                                            <p class="text-sm text-gray-500 flex items-center">
                                                                <span class="py-1 px-2 bg-green-300 text-white rounded">Unit Access Is On</span>
                                                            </p>
                                                        <?php else: ?>
                                                            <p class="text-sm text-gray-500 flex items-center">
                                                                <span class="py-1 px-2 bg-red-300 text-white rounded">Unit Access Is Off</span>
                                                            </p>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>
                                
                                <!-- account details -->
                                <div class="border-b border-gray-200 py-3">
                                    <div class="flex justify-between items-center">
                                        <h3 class="text-lg font-semibold mb-2">Account Payments:</h3>
                                        <div class="inline-block p-1">
                                            <button onclick="togglePayments('<?php echo e($estate->uid); ?>')" class="bg-blue-500 text-white px-2 py-1 rounded-sm text-xs hover:bg-blue-600 motion-reduce:transform-none">
                                                Add Payment
                                            </button>
                                        </div>
                                    </div> 
                                        
                                    <div class="md:flex">
                                        <div class="w-full md:w-1/3 bg-gray-200 rounded-lg p-2 hidden" id="payments_<?php echo e($estate->uid); ?>">
                                            <div class="w-full max-w-sm mx-auto">
                                                <form action="<?php echo e(route('payment.store')); ?>" method="POST" enctype="multipart/form-data" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" id="landlord_id" name="landlord_id" value="<?php echo e($estate->landlord_id); ?>" required>
                                                    <input type="hidden" id="estate_id" name="estate_id" value="<?php echo e($estate->uid); ?>" required>
                                                    <div class="mb-4">
                                                        <label for="pay_mode" class="block text-gray-700 text-sm font-bold mb-2">Payment Mode</label>
                                                        <select id="pay_mode" class="w-full font-medium py-2 rounded text-gray-700" name="pay_mode" required>
                                                            <option class="block mt-1 w-full" value=""></option>
                                                            <option class="block mt-1 w-full" value="Mobile Money">Mobile Money</option>
                                                            <option class="block mt-1 w-full" value="Bank Payment">Bank Payments</option>
                                                        </select>      
                                                    </div>                                          
                                                    <div class="mb-4">
                                                        <label for="account_name" class="block text-gray-700 text-sm font-bold mb-2">Account Name/ Mobile Name</label>
                                                        <input type="text" id="account_name" name="account_name" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                                                    </div>
                                                    <div class="mb-4">
                                                        <label for="account_number" class="block text-gray-700 text-sm font-bold mb-2">Account Number/ Mobile Number </label>
                                                        <input type="number" id="account_number" name="account_number" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                                                    </div>
                                                    <div class="flex items-center justify-between">
                                                        <button type="submit" class="bg-blue-500 text-white px-3 py-1 rounded-sm text-sm hover:bg-blue-600 motion-reduce:transform-none">
                                                            Save
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                        <div class="w-full md:w-2/3 bg-gray-200 rounded-lg p-2 mt-4 md:mt-0">
                                            <div class="w-full bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                                                <div class="flex flex-col space-y-4">
                                                    <div>
                                                        <p class="text-lg font-semibold">Mobile Details</p>
                                                        <?php $__currentLoopData = $estate->payEstate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($pay->pay_mode == 'Mobile Money'): ?>
                                                                <p class="text-sm text-gray-500 flex items-center">
                                                                    <span><?php echo e($pay->account_name); ?>: <?php echo e($pay->account_number); ?></span>
                                                                    <button class="delete-pay ml-2 bg-red-500 text-white px-1 py-0 rounded-md"
                                                                            data-pay="<?php echo e($pay->id); ?>">
                                                                        &times;
                                                                    </button>
                                                                </p>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                    <div>
                                                        <p class="text-lg font-semibold">Bank Details</p>
                                                        <?php $__currentLoopData = $estate->payEstate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($pay->pay_mode == 'Bank Payment'): ?>
                                                                <p class="text-sm text-gray-500">
                                                                    <span><?php echo e($pay->account_name); ?>: <?php echo e($pay->account_number); ?></span>
                                                                    <button class="delete-pay ml-2 bg-red-500 text-white px-1 py-0 rounded-md"
                                                                            data-pay="<?php echo e($pay->id); ?>">
                                                                        &times;
                                                                    </button>
                                                                </p>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> 
                                    </div>
                                </div>

                                <!-- location details -->
                                <div>
                                    <div class="flex justify-between items-center">
                                        <h3 class="text-lg font-semibold mb-2">Location:</h3>
                                        <button onclick="getGeoPosition(<?php echo e(json_encode($estate)); ?>)" class="bg-blue-500 text-white px-3 py-1 rounded-sm text-sm">
                                            Reset Location
                                        </button>
                                    </div>
                                    <div class="flex items-center justify-between border-b border-gray-200 py-3">
                                        <div> 
                                            <?php if($estate->latitude): ?>
                                                <p class="text-lg font-semibold">Latitude:
                                                    <span class="text-black"> 
                                                        <span class="text-blue-500"><?php echo e($estate->latitude); ?></span>
                                                    </span>
                                                </p>
                                                <p class="text-lg font-semibold">Latitude:
                                                    <span class="text-black"> 
                                                        <span class="text-blue-500"><?php echo e($estate->longitude); ?></span>
                                                    </span>
                                                </p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <!-- Terms and Conditions Field -->
                                <div class="border-b border-gray-200 py-3">
                                    <div class="flex justify-between items-center">
                                        <h3 class="text-lg font-semibold mb-2">Estate Terms And Conditions</h3>
                                        <div class="inline-block p-1">
                                            <button onclick="toggleTerms('<?php echo e($estate->uid); ?>')" class="bg-blue-500 text-white px-2 py-1 rounded-sm text-xs hover:bg-blue-600 motion-reduce:transform-none">
                                                Update Terms
                                            </button>
                                        </div>
                                    </div>
                                    <div class="w-full bg-gray-200 rounded-lg p-2 hidden" id="terms_<?php echo e($estate->uid); ?>">
                                        <div class="w-full bg-white shadow-md rounded px-8 pt-6 pb-8">
                                            <form action="<?php echo e(route('estate.terms')); ?>" method="POST" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" id="landlord_id" name="landlord_id" value="<?php echo e($estate->landlord_id); ?>" required>
                                                <input type="hidden" id="estate_id" name="estate_id" value="<?php echo e($estate->uid); ?>" required>
                                                <div class="mb-4">
                                                    <label for="terms_conditions" class="block text-gray-700 text-sm font-bold mb-2">Update Terms and Conditions:</label>
                                                    <textarea name="terms_conditions" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required><?php echo $estate->terms_conditions; ?></textarea>
                                                </div>
                                                <div class="flex items-center justify-between">
                                                    <button type="submit" class="bg-blue-500 text-white px-3 py-1 rounded-sm text-sm hover:bg-blue-600 motion-reduce:transform-none">
                                                        Update
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="w-full bg-gray-200 rounded-lg p-2">
                                        <div class="w-full bg-white shadow-md rounded px-8 pt-6 pb-8">
                                            <?php echo $estate->terms_conditions; ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit estate')): ?>
                                <!-- Description Field -->
                                <div class="border-b border-gray-200 py-3">
                                    <div class="flex justify-between items-center">
                                        <h3 class="text-lg font-semibold mb-2">Estate Description</h3>
                                        <div class="inline-block p-1">
                                            <button onclick="toggleDescription('<?php echo e($estate->uid); ?>')" class="bg-blue-500 text-white px-2 py-1 rounded-sm text-xs hover:bg-blue-600 motion-reduce:transform-none">
                                                Update Description
                                            </button>
                                        </div>
                                    </div>
                                    <!-- Description -->
                                    <div class="w-full bg-gray-200 rounded-lg p-2 hidden" id="description_<?php echo e($estate->uid); ?>">
                                        <div class="w-full bg-white shadow-md rounded px-8 pt-6 pb-8">
                                            <form action="<?php echo e(route('estate.description')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" id="landlord_id" name="landlord_id" value="<?php echo e($estate->landlord_id); ?>" required>
                                                <input type="hidden" id="estate_id" name="estate_id" value="<?php echo e($estate->uid); ?>" required>
                                                <div class="mb-4">
                                                    <label for="description" class="block text-gray-700 text-sm font-bold mb-2">Update Description:</label>
                                                    <textarea id="editor" name="description" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required><?php echo $estate->description; ?></textarea>
                                                </div>
                                                <div class="flex items-center justify-between">
                                                    <button type="submit" class="bg-blue-500 text-white px-3 py-1 rounded-sm text-sm hover:bg-blue-600 motion-reduce:transform-none">
                                                        Update
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                    <div class="w-full bg-gray-200 rounded-lg p-2">
                                        <div class="w-full bg-white shadow-md rounded px-8 pt-6 pb-8">
                                            <?php echo $estate->description; ?>

                                        </div>
                                    </div>
                                </div>

                                <!-- Videos and Images -->
                                <div class="border-b border-gray-200 py-3">
                                    <div class="flex justify-between items-center">
                                        <h3 class="text-lg font-semibold mb-2">Media</h3>
                                    </div>
                                    <!-- Videos -->
                                    <div class="flex flex-col space-y-4 md:flex-row md:space-y-0 md:space-x-4 mb-2">
                                        <div class="w-full md:w-1/3 bg-gray-200 rounded-lg p-2">
                                            <video controls class="w-full h-48 md:h-40 rounded-lg">
                                                <source src="<?php echo e(asset('storage/estate_videos')); ?>/<?php echo e($estate->video); ?>" type="video/mp4">
                                                Your browser does not support the video tag.
                                            </video>
                                        </div>
                                        <div class="w-full md:w-1/3 bg-gray-200 rounded-lg p-2">
                                            <div class="w-full max-w-sm mx-auto">
                                                <form action="<?php echo e(route('estate.video')); ?>" method="POST" enctype="multipart/form-data" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" id="landlord_id" name="landlord_id" value="<?php echo e($estate->landlord_id); ?>" required>
                                                    <input type="hidden" id="estate_id" name="estate_id" value="<?php echo e($estate->uid); ?>" required>
                                                    <div class="mb-4">
                                                        <label for="video" class="block text-gray-700 text-sm font-bold mb-2">Update Video:</label>
                                                        <input type="file" id="video" name="video" accept="video/*" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                                                    </div>
                                                    <div class="flex items-center justify-between">
                                                        <button type="submit" class="bg-blue-500 text-white px-3 py-1 rounded-sm text-sm hover:bg-blue-600 motion-reduce:transform-none">
                                                            Upload
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                        <!-- Upload Images -->
                                        <div class="w-full md:w-1/3 bg-gray-200 rounded-lg p-2">
                                            <div class="w-full max-w-sm mx-auto">
                                                <form action="<?php echo e(route('estate.images')); ?>" method="POST" enctype="multipart/form-data" class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" id="landlord_id" name="landlord_id" value="<?php echo e($estate->landlord_id); ?>" required>
                                                    <input type="hidden" id="estate_id" name="estate_id" value="<?php echo e($estate->uid); ?>" required>
                                                    <div class="mb-4">
                                                        <label for="images" class="block text-gray-700 text-sm font-bold mb-2">Upload Images: 10 images only</label>
                                                        <input type="file" id="images" name="images[]" accept="image/*" multiple class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" required>
                                                    </div>
                                                    <div class="flex items-center justify-between">
                                                        <button type="submit" class="bg-blue-500 text-white px-3 py-1 rounded-sm text-sm hover:bg-blue-600 motion-reduce:transform-none">
                                                            Upload
                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Display Images -->
                                    <div class="flex flex-wrap -mx-4">
                                        <?php if($estate->images): ?>
                                            <?php $__currentLoopData = explode(',', $estate->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="w-full sm:w-1/2 md:w-1/3 lg:w-1/4 xl:w-1/5 px-4 mb-4">
                                                    <div class="bg-gray-200 rounded-lg p-2 relative">
                                                        <img src="<?php echo e(asset('storage/estate_images/' . $estate->landlord_id . '/' . $imageName)); ?>" alt="Image" class="w-full rounded-lg">
                                                        <button class="absolute top-0 right-0 px-2 py-1 bg-red-500 text-white rounded-md delete-image" 
                                                            data-estate-uid="<?php echo e($estate->uid); ?>"
                                                            data-estate-landlord-id="<?php echo e($estate->landlord_id); ?>"
                                                            data-image="<?php echo e($imageName); ?>">
                                                                &times;
                                                        </button>
                                                    </div>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h2 class="text-xl font-bold mb-2">No Estate Registered</h2>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php echo $__env->make('estates.estate-location', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    // toggle the entire Estate
    function showContent(sectionId) {
        const sections = document.querySelectorAll('[id^="content_"]');
        sections.forEach(section => {
            if (section.id === `content_${sectionId}`) {
                section.classList.toggle('hidden');
            } else {
                section.classList.add('hidden');
            }
        });
    }
    
    $(document).ready(function() {
        $('.delete-image').on('click', function() {
            $(this).parent().remove();
            var imageName = $(this).data('image');
            var estateUid = $(this).data('estate-uid');
            var estateLandlordId = $(this).data('estate-landlord-id');
            // console.log(imageName);
            $.ajaxSetup({
                headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            // Send an AJAX request to delete the image
            $.ajax({
                url: '<?php echo e(route('image.delete')); ?>', // Replace with your route for deleting images
                method: 'POST',
                data: { image: imageName,
                        estateUid: estateUid,
                        estateLandlordId: estateLandlordId },
                success: function(response) {
                    if (response.success) {
                        // On success, remove the image's parent div
                        $(this).parent().remove();
                    } else {
                        // Handle error or display a message
                        console.log(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    // Handle error
                    console.error(error);
                }
            });
        });
    });

    $(document).ready(function() {
        $('.delete-pay').on('click', function() {
            $(this).parent().remove();
            var payName = $(this).data('pay');
            // console.log(imageName);
            $.ajaxSetup({
                headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            // Send an AJAX request to delete the image
            $.ajax({
                url: '<?php echo e(route('payment.delete')); ?>', 
                method: 'POST',
                data: { pay_id: payName,
                },
                success: function(response) {
                    if (response.success) {
                        // On success, remove the image's parent div
                        $(this).parent().remove();
                    } else {
                        // Handle error or display a message
                        console.log(response.message);
                    }
                },
                error: function(xhr, status, error) {
                    // Handle error
                    console.error(error);
                }
            });
        });
    });
    
    // Function to handle estate filtering based on search query
    function filterEstates() {
        const searchText = document.getElementById('estateSearch').value.toLowerCase();
        const estateButtons = document.querySelectorAll('#estateContainer button');
        
        estateButtons.forEach(button => {
            const estateName = button.textContent.toLowerCase();
            
            if (estateName.includes(searchText)) {
                button.style.display = 'block'; 
            } else {
                button.style.display = 'none'; 
            }
        });
    }
    document.getElementById('estateSearch').addEventListener('input', filterEstates);
    
    function toggleTerms(estateUid) {
        const element = document.getElementById(`terms_${estateUid}`);
        if (element) {
            element.classList.toggle('hidden');
        }
    }

    function toggleDescription(estateUid) {
        const element = document.getElementById(`description_${estateUid}`);
        if (element) {
            element.classList.toggle('hidden');
        }
    }

    function togglePayments(estateUid) {
        const element = document.getElementById(`payments_${estateUid}`);
        if (element) {
            element.classList.toggle('hidden');
        }
    }

</script>


<?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/estates/index.blade.php ENDPATH**/ ?>