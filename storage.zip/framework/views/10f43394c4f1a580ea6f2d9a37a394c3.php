<?php echo $__env->make('dashboard.tenant-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?> 
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.nav-link','data' => ['href' => ''.e(route('my.unit')).'','active' => request()->routeIs('my.unit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('my.unit')).'','active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(request()->routeIs('my.unit'))]); ?>
                <?php echo e(__('My Units')); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>
        </h2>
        <h4>  
            <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => ['class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>  
            <?php if(session('error')): ?>
                <span class="bg-red-500 text-white rounded">
                    <?php echo e(session('error')); ?>

                </span>
            <?php endif; ?>
            <?php if(session('success')): ?>
                <span class="bg-green-500 text-white rounded">
                    <?php echo e(session('success')); ?>

                </span>
            <?php endif; ?>
        </h4>
        <h6>
            <div id="error-container"></div>
        </h6>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="max-w-7xl mx-auto p-6">
                    Reports
                    <div class="flex flex-col md:flex-row justify-center items-center">
                        <div class="w-full md:w-1/3 p-4">
                            <h3 class="text-center mb-4">Rental Houses Vs Active Occupants</h3>
                            <canvas id="rentalPieChart"></canvas>
                        </div>
                        <div class="w-full md:w-1/2 p-4">
                            <h3 class="text-center mb-4">Number Of Estates Per District</h3>
                            <canvas id="districtBarChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php echo $__env->make('dashboard.user_location', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    $(document).ready(function() {
        // Make an AJAX request to fetch rentals
        $.ajax({
            url: '<?php echo e(route('pie.rentals')); ?>',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                const rentals = response.rentals;

                const labels = [];
                const counts = [];

                rentals.forEach(rental => {
                    labels.push(rental.name); 
                    const unitsWithStatusOne = rental.rental_units.filter(unit => unit.status === 1);
                    counts.push(unitsWithStatusOne.length); 
                });

                const ctx = document.getElementById('rentalPieChart').getContext('2d');
                rentalPieChart = new Chart(ctx, {
                    type: 'pie',
                    data: {
                        labels: labels,
                        datasets: [{
                            data: counts,
                            backgroundColor: [
                                'rgba(255, 99, 132, 0.7)',
                                'rgba(54, 162, 235, 0.7)',
                                'rgba(255, 206, 86, 0.7)',
                                'rgba(75, 192, 192, 0.7)',
                                'rgba(153, 102, 255, 0.7)', 
                                'rgba(255, 159, 64, 0.7)', 
                                'rgba(0, 255, 255, 0.7)', 
                                'rgba(255, 0, 255, 0.7)',
                            ],
                            borderWidth: 1,
                        }],
                    },
                    options: {
                        responsive: true,
                        legend: {
                            position: 'bottom',
                        },
                        title: {
                            display: true,
                            text: 'Rental Type Occupied Most by Units Occupied',
                        },
                    },
                });
            },
            error: function(error) {
                console.error('Error fetching rentals:', error);
            }
        }); 
    });

    // Districts and their categorical rental estates
    $(document).ready(function() {
        // Make an AJAX request to fetch rentals
        $.ajax({
            url: '<?php echo e(route('bar.estates')); ?>',
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                const districtEstates = response.districtEstates;

                const districts = Object.keys(districtEstates);
                const estatesInfo = Object.values(districtEstates);
                const estate_rental = estatesInfo.map(array => array.map(estate => estate.rental_name.name));
                
                function countOccurrences(arr) {
                    const counts = {};
                    arr.forEach(item => {
                        counts[item] = (counts[item] || 0) + 1;
                    });
                    return counts;
                }

                const estateCount = estatesInfo.map(array => array.length);
                const formattedResults = estate_rental.map(array => {
                    const counts = countOccurrences(array);
                    return Object.entries(counts)
                        .map(([key, value]) => `${key} ${value}`)
                        .join(', ');
                });

                // Combine estate count and formatted results for each district
                const mergedData = formattedResults.map((formattedResult, index) => {
                    return `${formattedResult}, Number of Estates: ${estateCount[index]}`;
                });

                // Create a bar chart using Chart.js with tooltips displaying custom text
                var ctx = document.getElementById('districtBarChart').getContext('2d');
                const myBarChart = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: districts,
                        datasets: [{
                            label: 'Number of Estates',
                            data: estateCount,
                            backgroundColor: 'rgba(54, 162, 235, 0.7)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: (context) => {
                                        // Display mergedData for each district in tooltips
                                        return mergedData[context.dataIndex];
                                    }
                                }
                            }
                        },
                        legend: {
                            display: false
                        },
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            },
            error: function(error) {
                console.error('Error fetching rentals:', error);
            }
        }); 
    });

</script><?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/dashboard/dashboard.blade.php ENDPATH**/ ?>