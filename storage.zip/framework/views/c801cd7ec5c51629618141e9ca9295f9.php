<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>