<div class="hidden sm:block">
    <div class="py-8">
        <div class="border-t border-gray-200"></div>
    </div>
</div>
<?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/components/section-border.blade.php ENDPATH**/ ?>