<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<title>My Units | YoRentos</title>
<?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section class="price_section layout_padding-bottom">
    <div class="container">
        <div class="container-header">
            <h2 class="rental_heading">
                <?php echo e(__('These Are The Units You Reside In. ')); ?> <?php echo e(auth()->user()->name); ?>

            </h2>
        </div>
        <div class="price_container">
            <?php $__empty_1 = true; $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php
                    // Calculate the difference in days
                    $nowDate = \Carbon\Carbon::now();
                    $endDate = \Carbon\Carbon::parse($unit->lease_stop);
                    $daysLeft = $nowDate->diffInDays($endDate);
                ?>
                <div class="box">
                    <div class="detail-box">
                        <div class="heading-box">
                            <h6>
                                <?php echo e($unit->unit); ?> || <?php echo e($unit->EstateName->estate); ?>

                            </h6>
                        </div>
                        <div class="text-box">
                            <h2>
                                <?php echo e($unit->price); ?>

                            </h2>
                            <h2>
                                <?php echo e(__('Lease Start: ')); ?><br> <?php echo e($unit->lease_start); ?>

                            </h2>
                            <h2>
                                <?php echo e(__('Lease End: ')); ?><br> <?php echo e($unit->lease_stop); ?>

                            </h2>
                            <h2>
                                <?php echo e($daysLeft); ?> days left
                            </h2>
                            <ul>
                                <li>
                                    <?php echo e($unit->rentalName->name); ?>

                                </li>
                                <li>
                                    <?php echo e($unit->durationName->duration); ?>

                                </li>
                                <li>
                                    <?php echo e($unit->square_footage); ?>

                                </li>
                                <span>
                                    <li>
                                        <?php echo e($unit->description); ?>

                                    </li>
                                    <li>
                                        <?php
                                            $resourcesArray = json_decode($unit->resources);
                                        ?>
                                        <?php echo e(is_array($resourcesArray) ? implode(', ', $resourcesArray) : $unit->resources); ?>

                                    </li>
                                </span>
                                <h2>
                                    <strong><?php echo e(__('Terms & Conditions: ')); ?></strong><br>
                                    <?php if($unit->sponsored == 1): ?>
                                        <a href="<?php echo e(route('confirm.terms', $unit)); ?>"class="badge bg-success"><?php echo e(__('Accepted')); ?></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('confirm.terms', $unit)); ?>" class="badge bg-danger"><?php echo e(__('Unaccepted')); ?></a>
                                    <?php endif; ?>
                                </h2>
                            </ul>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="container-header">
                    <h2 class="rental_heading">
                        <?php echo e(__('No Unit Assigned To You.')); ?>

                    </h2>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/tenant/units.blade.php ENDPATH**/ ?>