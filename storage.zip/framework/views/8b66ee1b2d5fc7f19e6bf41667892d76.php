</head>

<body class="sub_page">
  <div class="hero_area">
    <!-- header section strats -->
    <header class="header_section">
      <div class="container-fluid">
        <nav class="navbar navbar-expand-lg custom_nav-container">
            <a class="navbar-brand" href="/">
                <img src="<?php echo e(asset('frontend/images/logo.png')); ?>" alt="" style="height: 60px; width: 160px;"/>
            </a>
          <div class="navbar-collapse" id="">

            <div class="custom_menu-btn">
              <button onclick="toggleNav()">
                <span class="s-1">

                </span>
                <span class="s-2">

                </span>
                <span class="s-3">

                </span>
              </button>
            </div>
            <div id="myNav" class="overlay">
              <div class="overlay-content">
                <a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('Dashboard')); ?></a>
                <?php $__currentLoopData = $rental; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <a href="<?php echo e(route('rental.type', $item->slug)); ?>"><?php echo e($item->name); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('my.unit')); ?>"><?php echo e(__('My Units')); ?></a>
                <a href="/user/profile"><?php echo e(__('profile')); ?></a>
                <!-- Authentication -->
                <form method="POST" action="<?php echo e(route('logout')); ?>" x-data>
                    <?php echo csrf_field(); ?>
                    <a href="<?php echo e(route('logout')); ?>"
                              @click.prevent="$root.submit();">
                        <?php echo e(__('Log Out')); ?>

                    </a>
                </form>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
  </div><?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/layouts/menu.blade.php ENDPATH**/ ?>