<?php echo e($slot); ?>

<?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>