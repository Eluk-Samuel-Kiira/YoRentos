</head>
<body class="font-sans antialiased">
    <div class="hero_area">
        <!-- header section strats -->
        <header class="header_section">
            <div class="container-fluid">
                <nav class="navbar navbar-expand-lg custom_nav-container">
                    <a class="navbar-brand" href="/">
                        <img src="<?php echo e(asset('frontend/images/logo.png')); ?>" alt=""/>
                    </a>
                    <h4>  
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => ['class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>  
                        <?php if(session('error')): ?>
                            <span class="bg-red-500 text-white rounded">
                                <?php echo e(session('error')); ?>

                            </span>
                        <?php endif; ?>
                        <?php if(session('success')): ?>
                            <span class="bg-green-500 text-white rounded">
                                <?php echo e(session('success')); ?>

                            </span>
                        <?php endif; ?>
                    </h4>
                    <div class="navbar-collapse" id="">
                        <div class="custom_menu-btn">
                            <button onclick="toggleNav()">
                                <span class="s-1">
                                </span>
                                <span class="s-2">
                                </span>
                                <span class="s-3">
                                </span>
                            </button>
                        </div>
                        <div id="myNav" class="overlay">
                            <div class="overlay-content">
                                <a href="/">Home</a>
                                <a href="about.html">About</a>
                                <a href="<?php echo e(route('login')); ?>">Login</a>
                                <a href="<?php echo e(route('register')); ?>">Register</a>
                            </div>
                        </div>
                    </div>
                </nav>
            </div>
        </header>
    <?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/layouts/navigation.blade.php ENDPATH**/ ?>