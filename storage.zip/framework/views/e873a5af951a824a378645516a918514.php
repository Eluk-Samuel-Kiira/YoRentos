<a href="/">
    <img src="<?php echo e(asset('frontend/images/logo.png')); ?>" alt="logo" style="height: 80px; width: 180px;"/>
</a>
<?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/components/authentication-card-logo.blade.php ENDPATH**/ ?>