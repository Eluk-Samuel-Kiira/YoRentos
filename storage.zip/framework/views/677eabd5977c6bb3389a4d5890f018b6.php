<tr>
<td>
<table class="footer" align="center" width="570" cellpadding="0" cellspacing="0" role="presentation">
<tr>
<td class="content-cell" align="center">
<?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

</td>
</tr>
</table>
</td>
</tr>
<?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/vendor/laravel/framework/src/Illuminate/Mail/resources/views/html/footer.blade.php ENDPATH**/ ?>