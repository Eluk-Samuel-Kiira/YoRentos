<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<title>Welcome | YoRentos</title>
<?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Introduction section -->
        <h6>
            <div id="error-container"></div>
        </h6>
        <section class="slider_section ">
            <div class="container-fluid">
                <div class="col-md-4 offset-md-1">
                    <div class="detail-box">
                        <h1>
                            <span> Uganda's</span> <br>
                            <div>
                                Apartments &<br>
                                Rental Houses
                            </div>
                        </h1>
                        <p>
                            <b>"Our mission is to facilitate connections between tenants and landlords in Uganda, fostering a seamless and 
                                secure rental experience. We aim to bridge the gap between those seeking rental accommodations and property owners,
                                ensuring satisfaction and trust among all parties."
                            <b>
                        </p>
                        <div class="btn-box">
                            <a href="<?php echo e(route('register')); ?>" class="">
                                Get Stared
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end Introduction section -->
    </div>

    <!-- newly sponsored houses section -->
    <section class="sale_section layout_padding">
        <div class="container-fluid">
            <div class="container-header">
                <h2 class="rental_heading">
                    <?php echo e(__('Top Quality Houses Available In The Country')); ?>

                </h2>
            </div>
            <div class="sale_container">
                <?php 
                    $imageCount = 0;
                ?>
                <?php $__empty_1 = true; $__currentLoopData = $newly_estates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="box">
                        <div class="img-box">
                            <div class="carousel">
                                <?php if($estate->images): ?>
                                    <?php $__currentLoopData = explode(',', $estate->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="slide">
                                            <img src="<?php echo e(asset('storage/estate_images/' . $estate->landlord_id . '/' . $imageName)); ?>" alt="" >
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div><img src="<?php echo e(asset('frontend/images/s-2.jpg')); ?>" alt=""></div>
                                <?php endif; ?>
                            </div>
                            <button class="prev" onclick="prevSlide(<?php echo e($imageCount); ?>)"><span class="arrow">&#9664;</span> </button>
                            <button class="next" onclick="nextSlide(<?php echo e($imageCount); ?>)"> <span class="arrow">&#9654;</span></button>
                            <?php $imageCount++ ?>
                        </div>
                        <div class="detail-box">
                            <h6>
                                <a href="<?php echo e(route('unit.detail', $estate)); ?>"><?php echo e($estate->estate); ?> </a>                           
                                <span class="btn btn-small">
                                <?php
                                    $minPrice = $estate->unitEstate->min('price');
                                    $maxPrice = $estate->unitEstate->max('price');
                                ?>
                                <?php if($minPrice !== null && $maxPrice !== null): ?>
                                    <?php echo e($minPrice); ?> - <?php echo e($maxPrice); ?>

                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                                </span>
                            </h6>
                            <p>
                                <span class="btn btn-small">
                                    <?php
                                        $availableUnits = $estate->unitEstate->where('status', 0)->count();
                                        $allUnits = $estate->unitEstate->count();
                                    ?>
                                        <?php echo e(__('Units Available: ')); ?>

                                    <?php if($availableUnits !== 0): ?> 
                                        <?php echo e($availableUnits); ?>/<?php echo e($allUnits); ?>

                                    <?php else: ?>
                                        <?php echo e(__('NONE')); ?>

                                    <?php endif; ?>
                                </span>
                                <span class="btn btn-small">
                                    <img src="<?php echo e(asset('frontend/images/location.png')); ?>" width="10px" style="display: inline-block; vertical-align: middle; margin-right: 5px;" alt="">
                                    <?php echo e($estate->villageEstate->village); ?>

                                </span>
                                <span class="btn btn-small">
                                    <?php echo e($estate->unit_no); ?><?php echo e(__(' Reviews')); ?>

                                </span>
                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>
                        <?php echo e(__('There are no Sponsored Estates')); ?>

                    </p>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <!-- end newly sponsored houses section -->

    <!-- within area -->
    <section>
        <div class="slider-container">
            <div class="container-header">
                <h2 class="rental_heading">             
                    <input id="districtName" type="text" style="border: 0px;" disabled>
                </h2>
            </div>
            <div class="slider scroll-container">
                <div class="scroll-content">
                    <div class="slided item">
                        <!-- contents come here -->
                    </div>
                    <div>
                        <?php echo e(__('Your District is Not Supported Yet or kindly  ')); ?>

                        <div>
                            <a href="/" class="btn-small">Refresh</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- within area -->

    <!--  sponsored houses section -->
    <section class="sale_section layout_padding">
        <div class="container-fluid">
            <div class="container-header">
                <h2 class="rental_heading">
                    <?php echo e(__('Other Quality Houses')); ?>

                </h2>
            </div>
            <div class="sale_container">
                <?php $__empty_1 = true; $__currentLoopData = $early_estates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="box">
                        <div class="img-box">
                            <div class="carousel">
                                <?php if($estate->images): ?>
                                    <?php $__currentLoopData = explode(',', $estate->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imageName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="slide">
                                            <img src="<?php echo e(asset('storage/estate_images/' . $estate->landlord_id . '/' . $imageName)); ?>" alt="" >
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <div><img src="<?php echo e(asset('frontend/images/s-2.jpg')); ?>" alt=""></div>
                                <?php endif; ?>
                            </div>
                            <button class="prev" onclick="prevSlide(<?php echo e($imageCount); ?>)"><span class="arrow">&#9664;</span> </button>
                            <button class="next" onclick="nextSlide(<?php echo e($imageCount); ?>)"> <span class="arrow">&#9654;</span></button>
                            <?php $imageCount++ ?>
                        </div>
                        <div class="detail-box">
                            <h6>
                                <a href="<?php echo e(route('unit.detail', $estate)); ?>"><?php echo e($estate->estate); ?> </a>                           
                                <span class="btn btn-small">
                                <?php
                                    $minPrice = $estate->unitEstate->min('price');
                                    $maxPrice = $estate->unitEstate->max('price');
                                ?>
                                <?php if($minPrice !== null && $maxPrice !== null): ?>
                                    <?php echo e($minPrice); ?> - <?php echo e($maxPrice); ?>

                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                                </span>
                            </h6>
                            <p>
                                <span class="btn btn-small">
                                    <?php
                                        $availableUnits = $estate->unitEstate->where('status', 0)->count();
                                        $allUnits = $estate->unitEstate->count();
                                    ?>
                                        <?php echo e(__('Units Available: ')); ?>

                                    <?php if($availableUnits !== 0): ?> 
                                        <?php echo e($availableUnits); ?>/<?php echo e($allUnits); ?>

                                    <?php else: ?>
                                        <?php echo e(__('NONE')); ?>

                                    <?php endif; ?>
                                </span>
                                <span class="btn btn-small">
                                    <img src="<?php echo e(asset('frontend/images/location.png')); ?>" width="10px" style="display: inline-block; vertical-align: middle; margin-right: 5px;" alt="">
                                    <?php echo e($estate->villageEstate->village); ?>

                                </span>
                                <span class="btn btn-small">
                                    <?php echo e($estate->unit_no); ?><?php echo e(__(' Reviews')); ?>

                                </span>
                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>
                        <?php echo e(__('There are no Sponsored Estates')); ?>

                    </p>
                <?php endif; ?>
            </div>
            <div class="btn-box">
                <a href="<?php echo e(route('register')); ?>">
                Find More
                </a>
            </div>
        </div>
    </section>
    <!-- end  sponsored houses section -->

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('dashboard.user_location', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/landing_page/home.blade.php ENDPATH**/ ?>