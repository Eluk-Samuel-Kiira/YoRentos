<?php echo $__env->make('dashboard.tenant-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Rental List')); ?> 
        </h2>
     <?php $__env->endSlot(); ?>
    
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <div class="max-w-7xl mx-auto p-6">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage all')): ?>
                        <button id="openCreateRental" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                            Add Rental
                        </button>
                        <button class="bg-green-500 text-white font-bold py-2 px-4 rounded">
                            <?php echo e($estates->count()); ?> <?php echo e(__('Estates')); ?>

                        </button>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create estate')): ?>
                        <button id="openCreateEstate" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                            Add Estate
                        </button>
                    <?php endif; ?>
                    <h4>  
                        <?php if (isset($component)) { $__componentOriginal71c6471fa76ce19017edc287b6f4508c = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.validation-errors','data' => ['class' => 'mb-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal71c6471fa76ce19017edc287b6f4508c)): ?>
<?php $component = $__componentOriginal71c6471fa76ce19017edc287b6f4508c; ?>
<?php unset($__componentOriginal71c6471fa76ce19017edc287b6f4508c); ?>
<?php endif; ?>  
                        <?php if(session('error')): ?>
                            <span class="bg-red-500 text-white rounded">
                                <?php echo e(session('error')); ?>

                            </span>
                        <?php endif; ?>
                        <?php if(session('success')): ?>
                            <span class="bg-green-500 text-white rounded">
                                <?php echo e(session('success')); ?>

                            </span>
                        <?php endif; ?>
                    </h4>
                    
                    <div class="table-responsive" style="overflow-x: auto;" id="rentalTable">
                        <div class="container mx-auto mt-8">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create estate')): ?>
                                <?php echo $__env->make('rentals.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage all')): ?>
                                <button onclick="hideTable()" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                                    &times;Hide
                                </button>
                                <table class="min-w-full border border-blue-500 text-gray-500">
                                    <thead>
                                        <tr>
                                            <th class="py-2 px-4 border border-blue-500">ID</th>
                                            <th class="py-2 px-4 border border-blue-500">Rental Name</th>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage all')): ?>
                                                <th class="py-2 px-4 border border-blue-500">Status</th>
                                                <th class="py-2 px-4 border border-blue-500">Edit</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody id="rental-list">
                                        <?php $__empty_1 = true; $__currentLoopData = $rentals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                    <td class="py-2 px-4 border-b border-r"><?php echo e($rental->id); ?></td>
                                                    <td class="py-2 px-4 border-b border-r"><?php echo e($rental->name); ?></td>
                                                    <td class="py-2 px-3 border-b border-r">
                                                        <a href="<?php echo e(route('rental.status',$rental)); ?>" class="py-1 px-2 
                                                            <?php echo e($rental->status == 1 ? 'bg-green-300' : 'bg-red-300'); ?> 
                                                            text-white rounded hover:<?php echo e($rental->status == 1 ? 'bg-green-500' : 'bg-red-500'); ?>">
                                                            <?php echo e($rental->status == 1 ? 'Active' : 'Inactive'); ?>

                                                        </a>
                                                    </td>
                                                    <td class="py-2 px-4 border-b border-r">
                                                        <a href="#" onclick="openRentalModal(<?php echo e(json_encode($rental)); ?>)" class="py-1 px-2 bg-blue-300 text-white rounded hover:bg-blue-500">
                                                            <?php echo e(__('Edit')); ?>

                                                        </a>
                                                    </td>
                                                    <?php echo $__env->make('rentals.edit-rental', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <td class="py-2 px-4 border-b border-r"><?php echo e(__('No Rentals Available')); ?></td>
                                            <?php endif; ?>
                                    </tbody>
                                </table>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Estates Table -->
                    <div class="table-responsive" style="overflow-x: auto;">
                        <div class="container mx-auto mt-8">                            
                            <input type="text" class="rounded text-gray-500" id="estateSearch" placeholder="Search Estate or uid or village">
                            <table class="min-w-full border border-blue-500 text-gray-500">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create estate')): ?>
                                    <?php echo $__env->make('estates.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>
                                <thead>
                                    <tr>
                                        <th class="py-2 px-4 border border-blue-500">ID</th>
                                        <th class="py-2 px-4 border border-blue-500">Rental Name</th>
                                        <th class="py-2 px-4 border border-blue-500">Estate Name</th>
                                        <th class="py-2 px-4 border border-blue-500">Broker</th>
                                        <th class="py-2 px-4 border border-blue-500">Village</th>
                                        <th class="py-2 px-4 border border-blue-500">Latitude</th>
                                        <th class="py-2 px-4 border border-blue-500">Longitude</th>
                                        <th class="py-2 px-4 border border-blue-500">Views</th>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage all')): ?>
                                            <th class="py-2 px-4 border border-blue-500">Sponsored</th>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update estate')): ?>
                                            <th class="py-2 px-4 border border-blue-500">Status</th>
                                            <th class="py-2 px-4 border border-blue-500">View</th>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit estate')): ?>
                                            <th class="py-2 px-4 border border-blue-500">Edit</th>
                                        <?php endif; ?>
                                    </tr>
                                </thead>
                                <tbody id="estateTableBody">
                                <?php $__empty_1 = true; $__currentLoopData = $estates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if(auth()->user()->role == 'Admin' || auth()->user()->id == $estate->landlord_id || auth()->user()->id == $estate->broker_id): ?>
                                        <tr>
                                            <td class="py-2 px-4 border-b border-r"><?php echo e($estate->uid); ?></td>
                                            <td class="py-2 px-4 border-b border-r"><?php echo e($estate->rentalEstate->name); ?></td>
                                            <td class="py-2 px-4 border-b border-r"><?php echo e($estate->estate); ?></td>
                                            <td class="py-2 px-4 border-b border-r">
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($estate->broker_id == $user->id): ?>
                                                    <?php echo e($user->name); ?>

                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <td class="py-2 px-4 border-b border-r"><?php echo e($estate->villageEstate->village); ?></td>
                                            <td class="py-2 px-4 border-b border-r"><?php echo e($estate->latitude); ?></td>
                                            <td class="py-2 px-4 border-b border-r"><?php echo e($estate->longitude); ?></td>
                                            <td class="py-2 px-4 border-b border-r"><?php echo e($estate->unit_no); ?></td>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage all')): ?>
                                                <td class="py-2 px-4 border-b border-r">
                                                    <a href="<?php echo e(route('estate.status',$estate)); ?>" class="py-1 px-2 
                                                        <?php echo e($estate->sponsored == 1 ? 'bg-green-300' : 'bg-red-300'); ?> 
                                                        text-white rounded hover:<?php echo e($estate->sponsored == 1 ? 'bg-green-500' : 'bg-red-500'); ?>">
                                                        <?php echo e($estate->sponsored == 1 ? 'Yes' : 'No'); ?>

                                                    </a>
                                                </td>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update estate')): ?>
                                                <td class="py-2 px-3 border-b border-r">
                                                    <a href="<?php echo e(route('estate.status',$estate)); ?>" class="py-1 px-2 
                                                        <?php echo e($estate->status == 1 ? 'bg-green-300' : 'bg-red-300'); ?> 
                                                        text-white rounded hover:<?php echo e($estate->status == 1 ? 'bg-green-500' : 'bg-red-500'); ?>">
                                                        <?php echo e($estate->status == 1 ? 'Active' : 'Inactive'); ?>

                                                    </a>
                                                </td>
                                                <td class="py-2 px-4 border-b border-r">
                                                <a href="<?php echo e(route('estate.index')); ?>" class="py-1 px-2 bg-green-300 text-white rounded hover:bg-green-500">
                                                    <?php echo e(__('Show')); ?>

                                                </td>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit estate')): ?>
                                                <td class="py-2 px-4 border-b border-r">
                                                    <a href="#" onclick="openEstateModal(<?php echo e(json_encode($estate)); ?>)" class="py-1 px-2 bg-blue-300 text-white rounded hover:bg-blue-500">
                                                        <?php echo e(__('Edit')); ?>

                                                    </a>
                                                </td>
                                                <?php echo $__env->make('estates.edit-estate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <td class="py-2 px-4 border-b border-r"><?php echo e(__('No Estate Available')); ?></td>
                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<script>
    function hideTable() {
        const table = document.getElementById('rentalTable');
        if (table) {
            table.style.display = 'none';
        }
    }

    const searchInputEstate = document.getElementById('estateSearch');
    const tableBodyEstate = document.getElementById('estateTableBody');

    // Add event listener to the search input
    searchInputEstate.addEventListener('input', function () {
        const searchValueParish = this.value.toLowerCase().trim();
        const rowsParish = tableBodyEstate.getElementsByTagName('tr');

        // Loop through all table rows to check for matches and display/hide accordingly
        for (let row of rowsParish) {
            const estateId = row.getElementsByTagName('td')[0];
            const estateName = row.getElementsByTagName('td')[2];
            const villageName = row.getElementsByTagName('td')[4];

            if (villageName && estateName && estateId) {
                const textVillage = villageName.textContent || villageName.innerText;
                const textEstate = estateName.textContent || estateName.innerText;
                const textId = estateId.textContent || estateId.innerText;

                if (
                    textVillage.toLowerCase().includes(searchValueParish) ||
                    textEstate.toLowerCase().includes(searchValueParish) ||
                    textId.toLowerCase().includes(searchValueParish)
                ) {
                    row.style.display = ''; // Show the row if it contains the search input value
                } else {
                    row.style.display = 'none'; // Hide the row if it doesn't match the search input value
                }
            }
        }
    });


</script><?php /**PATH /home/u246610829/domains/stardena.com/public_html/YoRentos/resources/views/rentals/index.blade.php ENDPATH**/ ?>